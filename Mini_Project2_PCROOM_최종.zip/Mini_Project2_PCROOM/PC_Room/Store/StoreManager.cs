﻿using PC_Room.Interface;
using PC_Room.Member;
using PC_Room.Product;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PC_Room.Store
{
    //상품구매영수증추가, 상품구매영수증수정, 상품구매영수증제거, 상품구매영수증검색, 개별조회, 상품구매영수증전체목록
    class StoreManager : ManagerInterface
    {
        public ProductManager productMng { get; set; }
        ProductDAO productDAO = new ProductDAO();
        ProductDTO product = new ProductDTO();
        public MemberManager memberMng { get; set; }
        StoreDAO storeDAO = new StoreDAO();

        //상품구매영수증추가
        public void Add()
        {
            while (true)
            {
                //productMng.Search();
                Console.WriteLine("-------------");
                Console.Write("구매하실 상품명을 입력하세요 >> ");
                string name = Console.ReadLine();

                if (string.IsNullOrEmpty(name))
                {
                    Console.WriteLine("아무것도 입력하지 않으셨습니다. 다시입력해주세요.");
                    Console.ReadLine();
                    continue;
                }

                productMng.pName = name;
                productMng.SearchName();
                product = productMng.product;

                if (string.IsNullOrEmpty(product.Name))
                {
                    Console.WriteLine("찾으시는 상품이 없습니다. 상품명을 다시 입력하세요.");
                    Console.ReadLine();
                    continue;
                }

                Console.WriteLine("-- 선택한 상품 정보 --");
                productMng.PrintProduct_member();

                Console.WriteLine();
                Console.Write("구매하시겠습니까?(Y/N) : ");
                string YesNo = Console.ReadLine();

                if (YesNo == "Y" || YesNo == "y")
                {
                    //회원 소지금에서 가격만큼 차감
                    memberMng.member.Money -= product.Price;
                    //변경된 소지금 업데이트
                    memberMng.UpdateBuy();
                    //상품 재고 차감
                    productMng.product.Stock -= 1;
                    //변경된 재고 업데이트
                    productMng.UpdateStock();

                    Console.WriteLine();
                    Console.WriteLine("{0}님 {1}를 구매하셨습니다.", memberMng.member.Name, productMng.product.Name);
                    //Console.WriteLine("결제 후 소지금은 {0}원 입니다", memberMng.member.Money);
                    memberMng.PrintMember();
                    Console.ReadLine();
                    break;
                }
                else if (YesNo == "N" || YesNo == "n")
                {
                    Console.Clear();
                    Console.WriteLine("메인화면으로 돌아갑니다.");
                    Console.ReadKey();
                    break;
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("잘못 입력하셨습니다");
                    Console.Clear();
                    continue;
                }
            }     
        }

        //상품구매영수증 수정
        public void Update()
        {
            
        }

        //상품구매영수증 삭제
        public void Delete()
        {
            throw new NotImplementedException();
        }

        //상품구매영수증 검색
        public void Search()
        {
            throw new NotImplementedException();
        }

        //상품구매영수증 정보 출력
        public void PrintProduct()
        {

        }

        //상품구매영수증 전체목록
        public void PrintList()
        {
            throw new NotImplementedException();
        }
    }
}
