﻿using PC_Room.Interface;
using PC_Room.Member;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PC_Room.Store
{
    class StoreDAO : SQLInterface
    {

        public void Insert()
        {
            throw new NotImplementedException();
        }

        public void Update()
        {
            
        }

        public void Search()
        {
            throw new NotImplementedException();
        }

        public void SearchAll()
        {
            throw new NotImplementedException();
        }

        public void Delete()
        {
            throw new NotImplementedException();
        }
    }
}
