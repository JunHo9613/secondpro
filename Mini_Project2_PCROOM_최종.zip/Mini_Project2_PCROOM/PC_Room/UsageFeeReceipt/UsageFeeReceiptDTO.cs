﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PC_Room.UsageFeeReceipt
{
    class UsageFeeReceiptDTO
    {
        public UsageFeeReceiptDTO() {}

        public UsageFeeReceiptDTO(int idx, string id, string name, string phone, int seatNum, int time, int receivedMoney, int payment, int change, bool isMember)
        {
            Idx = idx;
            Id = id;
            Name = name;
            Phone = phone;
            SeatNum = seatNum;
            Time = time;
            ReceivedMoney = receivedMoney;
            Payment = payment;
            Change = change;
            IsMember = isMember;
        }

        public UsageFeeReceiptDTO(int inx, int memberIdx, string id, string name, string phone, 
                                    int seatNum, int time, int receivedMoney, int payment, int change, bool isMember, string paymentDate)
        {
            Idx = Idx;
            MemberIdx = memberIdx;
            Id = id;
            Name = name;
            Phone = phone;
            SeatNum = seatNum;
            Time = time;
            ReceivedMoney = receivedMoney;
            Payment = payment;
            Change = change;
            IsMember = isMember;
            PaymentDate = paymentDate;
        }

        public int Idx { get; set; }
        public int MemberIdx { get; set; }
        public string Id { get; set; }
        public string Name { get; set; }
        public string Phone { get; set; }
        public int SeatNum { get; set; }
        public int Time { get; set; }
        public int ReceivedMoney { get; set; }
        public int Payment { get; set; }
        public int Change { get; set; }
        public bool IsMember { get; set; }
        public string PaymentDate { get; set; }
    }
}
