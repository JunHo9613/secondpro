﻿using PC_Room.Interface;
using PC_Room.Member;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace PC_Room.UsageFeeReceipt
{
    class UsageFeeReceiptDAO : SQLInterface
    {
        public MemberDTO member { get; set; }
        public UsageFeeReceiptDTO usageFee { get; set; }
        public List<UsageFeeReceiptDTO> usageFeeList { get; set; }
        public string searchType { get; set; }

        //영수증 추가
        public void Insert()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DataBase.Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    var query = @"INSERT INTO [dbo].[UsageFeeReceipt_Tbl]
                                       ([MemberIdx]
                                       ,[Id]
                                       ,[Name]
                                       ,[Phone]
                                       ,[SeatNum]
                                       ,[Time]
                                       ,[ReceivedMoney]
                                       ,[Payment]
                                       ,[Change]
                                       ,[IsMember])
                                 VALUES
                                       (@MemberIdx
                                       ,@Id
                                       ,@Name
                                       ,@Phone
                                       ,@SeatNum
                                       ,@Time
                                       ,@ReceivedMoney
                                       ,@Payment
                                       ,@Change
                                       ,@IsMember) ";

                    cmd.CommandText = query;

                    cmd.Parameters.AddWithValue("@MemberIdx", usageFee.MemberIdx);
                    cmd.Parameters.AddWithValue("@Id", usageFee.Id);
                    cmd.Parameters.AddWithValue("@Name", usageFee.Name);
                    cmd.Parameters.AddWithValue("@Phone", usageFee.Phone);
                    cmd.Parameters.AddWithValue("@SeatNum", usageFee.SeatNum);
                    cmd.Parameters.AddWithValue("@Time", usageFee.Time);
                    cmd.Parameters.AddWithValue("@ReceivedMoney", usageFee.ReceivedMoney);
                    cmd.Parameters.AddWithValue("@Payment", usageFee.Payment);
                    cmd.Parameters.AddWithValue("@Change", usageFee.Change);
                    cmd.Parameters.AddWithValue("@IsMember", usageFee.IsMember.ToString());

                    var result = cmd.ExecuteNonQuery();

                    if (result == 1)
                    {
                        Console.WriteLine("-- 이용료 영수증 추가 성공 --");
                    }
                    else
                    {
                        Console.WriteLine("-- 이용료 영수증 추가 실패 --");
                    }
                    Console.ReadKey();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("UsageFeeReceipt Insert" + ex.Message);
            }
        }

        //영수증 수정
        public void Update()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DataBase.Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    var query = @"UPDATE [dbo].[UsageFeeReceipt_Tbl]
                                        SET [Id] = @Id
                                           ,[Name]= @Name
                                           ,[Phone]= @Phone
                                           ,[SeatNum]= @SeatNum
                                           ,[Time]= @Time
                                           ,[ReceivedMoney]= @ReceivedMoney
                                           ,[Payment]= @Payment
                                           ,[Change]= @Change
                                           ,[IsMember]= @IsMember 
                                        WHERE Idx = @Idx ";

                    cmd.CommandText = query;

                    cmd.Parameters.AddWithValue("@Id", usageFee.Id);
                    cmd.Parameters.AddWithValue("@Name", usageFee.Name);
                    cmd.Parameters.AddWithValue("@Phone", usageFee.Phone);
                    cmd.Parameters.AddWithValue("@SeatNum", usageFee.SeatNum);
                    cmd.Parameters.AddWithValue("@Time", usageFee.Time);
                    cmd.Parameters.AddWithValue("@ReceivedMoney", usageFee.ReceivedMoney);
                    cmd.Parameters.AddWithValue("@Payment", usageFee.Payment);
                    cmd.Parameters.AddWithValue("@Change", usageFee.Change);
                    cmd.Parameters.AddWithValue("@IsMember", usageFee.IsMember.ToString());
                    cmd.Parameters.AddWithValue("@Idx", usageFee.Idx);

                    var result = cmd.ExecuteNonQuery();
                    if (result == 1)
                    {
                        Console.WriteLine("-- 이용료 영수증 수정 성공 --");
                    }
                    else
                    {
                        Console.WriteLine("-- 이용료 영수증 수정 실패 --");
                    }
                    Console.ReadKey();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("UsageFeeReceipt Update" + ex.Message);
            }
        }
        //Id로 영수증 검색
        public void SearchID()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DataBase.Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    var query = "SELECT * FROM [dbo].[UsageFeeReceipt_Tbl] " +
                            " WHERE [Id] = @Id ";
                    cmd.CommandText = query;

                    cmd.Parameters.AddWithValue("@Id", usageFee.Id);

                    SqlDataReader reader = cmd.ExecuteReader();

                    string[] datas = new string[reader.FieldCount];
                    if (reader.Read())
                    {
                        for (int i = 0; i < reader.FieldCount; i++)
                            datas[i] = reader.GetValue(i).ToString();

                        usageFee.Idx = int.Parse(datas[0]);
                        usageFee.MemberIdx = int.Parse(datas[1]);
                        usageFee.Id = datas[2];
                        usageFee.Name = datas[3];
                        usageFee.Phone = datas[4];
                        usageFee.SeatNum = int.Parse(datas[5]);
                        usageFee.Time = int.Parse(datas[6]);
                        usageFee.ReceivedMoney = int.Parse(datas[7]);
                        usageFee.Payment = int.Parse(datas[8]);
                        usageFee.Change = int.Parse(datas[9]);
                        usageFee.IsMember = bool.Parse(datas[10]);
                        usageFee.PaymentDate = datas[11];
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("UsageFeeReceipt SearchID" + ex.Message);
            }
        }


        //Idx로 영수증 검색
        public void Search()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DataBase.Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    var query = "";

                    if (searchType.Equals("Idx"))
                    {
                        query = "SELECT * FROM [dbo].[UsageFeeReceipt_Tbl] " +
                            " WHERE [Idx] = @Idx ";
                    }
                    else if (searchType.Equals("Id"))
                    {
                        query = "SELECT * FROM [dbo].[UsageFeeReceipt_Tbl] " +
                            " WHERE [Id] = @Id ";
                    }
                    cmd.CommandText = query;

                    if (searchType.Equals("Idx")) { cmd.Parameters.AddWithValue("@Idx", usageFee.Idx); }
                    else if (searchType.Equals("Id")) { cmd.Parameters.AddWithValue("@Id", usageFee.Idx); }

                    SqlDataReader reader = cmd.ExecuteReader();

                    string[] datas = new string[reader.FieldCount];
                    if (reader.Read())
                    {
                        for (int i = 0; i < reader.FieldCount; i++)
                            datas[i] = reader.GetValue(i).ToString();

                        usageFee.Idx = int.Parse(datas[0]);
                        usageFee.MemberIdx = int.Parse(datas[1]);
                        usageFee.Id = datas[2];
                        usageFee.Name = datas[3];
                        usageFee.Phone = datas[4];
                        usageFee.SeatNum = int.Parse(datas[5]);
                        usageFee.Time = int.Parse(datas[6]);
                        usageFee.ReceivedMoney = int.Parse(datas[7]);
                        usageFee.Payment = int.Parse(datas[8]);
                        usageFee.Change = int.Parse(datas[9]);
                        usageFee.IsMember = bool.Parse(datas[10]);
                        usageFee.PaymentDate = datas[11];
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("UsageFeeReceipt Search" + ex.Message);
            }
        }

        //모든 영수증 정보 usageFeeList에 추가
        public void SearchAll()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DataBase.Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    var query = "SELECT * FROM [dbo].[UsageFeeReceipt_Tbl] ";
                    cmd.CommandText = query;

                    SqlDataReader reader = cmd.ExecuteReader();

                    string[] datas = new string[reader.FieldCount];

                    List<UsageFeeReceiptDTO> usageFeeList = new List<UsageFeeReceiptDTO>();
                    while (reader.Read())
                    {
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            datas[i] = reader.GetValue(i).ToString();
                        }

                        UsageFeeReceiptDTO usageFee = new UsageFeeReceiptDTO();
                        usageFee.Idx = int.Parse(datas[0]);
                        usageFee.MemberIdx = int.Parse(datas[1]);
                        usageFee.Id = datas[2];
                        usageFee.Name = datas[3];
                        usageFee.Phone = datas[4];
                        usageFee.SeatNum = int.Parse(datas[5]);
                        usageFee.Time = int.Parse(datas[6]);
                        usageFee.ReceivedMoney = int.Parse(datas[7]);
                        usageFee.Payment = int.Parse(datas[8]);
                        usageFee.Change = int.Parse(datas[9]);
                        usageFee.IsMember = bool.Parse(datas[10]);
                        usageFee.PaymentDate = datas[11];

                        usageFeeList.Add(usageFee);
                    }
                    this.usageFeeList = usageFeeList;

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("UsageFeeReceipt SearchAll" + ex.Message);
            }
        }

        //영수증 삭제
        public void Delete()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DataBase.Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    var query = "";

                    query = "DELETE FROM [dbo].[UsageFeeReceipt_Tbl] " +
                            " WHERE [Idx] = @Idx ";
                    cmd.CommandText = query;

                    cmd.Parameters.AddWithValue("@Idx", usageFee.Idx);

                    var result = cmd.ExecuteNonQuery();
                    if (result == 1)
                    {
                        Console.WriteLine("-- 영수증 삭제 성공 --");
                    }
                    else
                    {
                        Console.WriteLine("-- 영수증 삭제 실패 --");
                    }
                    Console.ReadKey();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("UsageFeeReceipt Delete" + ex.Message);
            }
        }
    }
}
