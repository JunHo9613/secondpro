﻿using PC_Room.Interface;
using PC_Room.Member;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PC_Room.UsageFeeReceipt
{
    class UsageFeeReceiptManager : ManagerInterface
    {
        public MemberDTO member { get; set; }
        List<MemberDTO> memberList = new List<MemberDTO>();
        MemberDAO memberDAO = new MemberDAO();

        UsageFeeReceiptDTO usageFee = new UsageFeeReceiptDTO();
        List<UsageFeeReceiptDTO> usageFeeList = new List<UsageFeeReceiptDTO>();
        UsageFeeReceiptDAO usageFeeDAO = new UsageFeeReceiptDAO();

        int time=0, payment=0, receivedMoney=0, change=0;

        public UsageFeeReceiptManager() { }

        public UsageFeeReceiptManager(MemberDTO member, int time, int receivedMoney, int payment, int change)
        {
            this.member = member;
            this.time = time;
            this.receivedMoney = receivedMoney;
            this.payment = payment;
            this.change = change;
        }

        //영수증 출력
        public void PrintUsageFee()
        {
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
            Console.WriteLine($"번호\t\t : {usageFee.Idx}");
            Console.WriteLine($"회원번호\t : {usageFee.MemberIdx}");
            Console.WriteLine($"아이디\t\t : {usageFee.Id}");
            Console.WriteLine($"이름\t\t : {usageFee.Name}");
            Console.WriteLine($"전화\t\t : {usageFee.Phone}");
            Console.WriteLine($"좌석\t\t : {usageFee.SeatNum}");
            Console.WriteLine($"시간\t\t : {usageFee.Time}");
            Console.WriteLine($"받은금액\t : {usageFee.ReceivedMoney}");
            Console.WriteLine($"결제금액\t : {usageFee.Payment}");
            Console.WriteLine($"남은금액\t : {usageFee.Change}");
            Console.WriteLine($"회원여부\t : {usageFee.IsMember}");
            Console.WriteLine($"등록날짜\t : {usageFee.PaymentDate}");
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
            Console.WriteLine();
        }

        //영수증 추가
        public void Add()
        {
            Console.WriteLine("PC방 이용료 결제 영수증 추가");
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");

            usageFee.MemberIdx = member.Idx;
            usageFee.Id = member.Id;
            usageFee.Name = member.Name;
            usageFee.Phone = member.Phone;
            usageFee.SeatNum = member.SeatNum;
            usageFee.Time = time;
            usageFee.ReceivedMoney = receivedMoney;
            usageFee.Payment = payment;
            usageFee.Change = change;
            usageFee.IsMember = member.IsMember;

            usageFeeDAO.usageFee = usageFee;
            usageFeeDAO.Insert();
        }

        //영수증 삭제
        public void Delete()
        {
            Console.WriteLine("PC방 이용료 영수증 삭제");
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
            Console.Write("영수증 번호 >> ");
            int idx = int.Parse(Console.ReadLine());
            bool isFind = false;

            foreach (var usageFee in usageFeeList)
            {
                if (usageFee.Idx == idx)
                {
                    isFind = true;
                    usageFeeDAO.usageFee = usageFee;
                    usageFeeDAO.Search();
                    this.usageFee = usageFeeDAO.usageFee;
                    PrintUsageFee();
                    Console.Write("선택한 영수증을 삭제하시겠습니까? [y/n]");
                    string answer = Console.ReadLine(); 
                    if (answer.ToUpper() == "Y")
                    {
                        usageFeeDAO.usageFee = usageFee;
                        usageFeeDAO.Delete();
                    }

                    break;
                }
            }

            if (!isFind)
            {
                Console.WriteLine("해당 번호의 영수증이 없습니다.");
            }
        }

        //전체 영수증
        public void PrintList()
        {

            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
            Console.WriteLine("PC방 이용료 전체 영수증");

            if (usageFeeList.Count == 0)
            {
                Console.WriteLine("등록된 영수증이 없습니다.");
            }
            else
            {
                usageFeeDAO.SearchAll();
                usageFeeList = usageFeeDAO.usageFeeList;

                foreach (var usageFee in usageFeeList)
                {
                    this.usageFee = usageFee;
                    PrintUsageFee();
                }
            }
            Console.ReadLine();
        }

        //usageFee의 Idx 값으로 찾는다
        public void Search()
        {
            //모든 영수증 정보 가져오기
            usageFeeDAO.SearchAll();
            usageFeeList = usageFeeDAO.usageFeeList;

            foreach (var u in usageFeeList)
            {
                if (member.Idx == u.MemberIdx && member.SeatNum == u.SeatNum)
                {
                    usageFeeDAO.usageFee = u;
                    usageFeeDAO.searchType = "Idx";
                    usageFeeDAO.Search();
                    usageFee = usageFeeDAO.usageFee;
                    break;
                }
            }
        }

        //usageFee의 Id 값으로 찾는다
        public void SearchId()
        {
            //모든 영수증 정보 가져오기
            usageFeeDAO.SearchAll();
            usageFeeList = usageFeeDAO.usageFeeList;

            foreach (var u in usageFeeList)
            {
                if (member.Id.Equals(u.Id))
                {
                    usageFeeDAO.usageFee = u;
                    usageFeeDAO.searchType = "Id";
                    usageFeeDAO.Search();
                    usageFee = usageFeeDAO.usageFee;
                    break;
                }
            }
        }

        //영수증 수정 안할꺼
        public void Update()
        {
            throw new NotImplementedException();
        }

        internal void VIPList()
        {
            throw new NotImplementedException();
        }
    }
}
