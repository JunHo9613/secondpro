﻿using PC_Room.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace PC_Room.Member
{
    class MemberDAO : SQLInterface
    {
        public MemberDTO member { get; set; }
        public List<MemberDTO> memberList { get; set; }

        //회원
        public void InsertMember(SqlCommand cmd)
        {
            var query = @"INSERT INTO [dbo].[Member_Tbl]
                                       ([Id]
                                       ,[Password]
                                       ,[Name]
                                       ,[Phone]
                                       ,[Address]
                                       ,[Money]
                                       ,[IsMember])
                                 VALUES
                                       (@Id
                                       ,@Password
                                       ,@Name
                                       ,@Phone
                                       ,@Address
                                       ,@Money
                                       ,@IsMember) ";

            cmd.CommandText = query;

            cmd.Parameters.AddWithValue("@Id", member.Id);
            cmd.Parameters.AddWithValue("@Password", member.Password);
            cmd.Parameters.AddWithValue("@Name", member.Name);
            cmd.Parameters.AddWithValue("@Phone", member.Phone);
            cmd.Parameters.AddWithValue("@Address", member.Address);
            cmd.Parameters.AddWithValue("@Money", member.Money);
            cmd.Parameters.AddWithValue("@IsMember", member.IsMember.ToString());
        }

        //비회원
        public void InsertNonMember(SqlCommand cmd)
        {
            var query = @"INSERT INTO [dbo].[Member_Tbl]
                                       ([Id]
                                       ,[Money]
                                       ,[IsMember])
                                 VALUES
                                       (@Id
                                       ,@Money
                                       ,@IsMember) ";

            cmd.CommandText = query;

            cmd.Parameters.AddWithValue("@Id", member.Id);
            cmd.Parameters.AddWithValue("@Money", member.Money);
            cmd.Parameters.AddWithValue("@IsMember", member.IsMember.ToString());
        }

        //회원/비회원추가
        public void Insert()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DataBase.Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    //IsMember == True : 회원가입
                    if (member.IsMember)
                    {
                        InsertMember(cmd);
                    }
                    //IsMember == False : 비회원
                    else
                    {
                        InsertNonMember(cmd);
                    }

                    var result = cmd.ExecuteNonQuery();

                    //회원가입
                    if (member.IsMember)
                    {
                        if (result == 1)
                        {
                            Console.WriteLine("-- 회원 추가 성공 --");
                        }
                        else
                        {
                            Console.WriteLine("-- 회원 추가 실패 --");
                        }
                    }
                    Console.ReadKey();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("MemberDAO Insert" + ex.Message);
            }
        }
        
        //자리번호 변경
        public void UpdateSeatNum()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DataBase.Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    var query = @"UPDATE [dbo].[Member_Tbl]
                                        SET [SeatNum]= @SeatNum
                                        WHERE Id = @Id ";

                    cmd.CommandText = query;

                    cmd.Parameters.AddWithValue("@SeatNum", member.SeatNum);
                    cmd.Parameters.AddWithValue("@Id", member.Id);

                    cmd.ExecuteNonQuery();
                    Console.ReadKey();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("MemberDAO UpdateSeatNum" + ex.Message);
            }
        }

        //상점 구매
        public void UpdateBuy()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DataBase.Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    var query = @"UPDATE [dbo].[Member_Tbl]
                                        SET [Money]= @Money
                                        WHERE [Idx] = @Idx ";

                    cmd.CommandText = query;

                    cmd.Parameters.AddWithValue("@Money", member.Money);
                    cmd.Parameters.AddWithValue("@Idx", member.Idx);

                    cmd.ExecuteNonQuery();
                    Console.ReadKey();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("MemberDAO UpdateBuy" + ex.Message);
            }
        }

        //사용료 결제 후 돈+남은시간 수정
        public void UpdateUsageFee()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DataBase.Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    var query = @"UPDATE [dbo].[Member_Tbl]
                                        SET [Money]= @Money
                                           ,[RemainingTime]= @RemainingTime
                                        WHERE Idx = @Idx ";

                    cmd.CommandText = query;

                    cmd.Parameters.AddWithValue("@Money", member.Money);
                    cmd.Parameters.AddWithValue("@RemainingTime", member.RemainingTime);
                    cmd.Parameters.AddWithValue("@Idx", member.Idx);

                    cmd.ExecuteNonQuery();
                    Console.ReadKey();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("MemberDAO UpdateUsageFee" + ex.Message);
            }
        }

        //관리자 회원정보 수정
        public void UpdateAdmin()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DataBase.Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    var query = @"UPDATE [dbo].[Member_Tbl]
                                        SET [Id] = @Id
                                           ,[Password]= @Password
                                           ,[Name]= @Name
                                           ,[Phone]= @Phone
                                           ,[Address]= @Address
                                           ,[Money]= @Money
                                           ,[RemainingTime]= @RemainingTime
                                           ,[isMember]= @isMember
                                        WHERE Idx = @Idx ";

                    cmd.CommandText = query;

                    cmd.Parameters.AddWithValue("@Id", member.Id);
                    cmd.Parameters.AddWithValue("@Password", member.Password);
                    cmd.Parameters.AddWithValue("@Name", member.Name);
                    cmd.Parameters.AddWithValue("@Phone", member.Phone);
                    cmd.Parameters.AddWithValue("@Address", member.Address);
                    cmd.Parameters.AddWithValue("@Money", member.Money);
                    cmd.Parameters.AddWithValue("@RemainingTime", member.RemainingTime);
                    cmd.Parameters.AddWithValue("@isMember", member.IsMember.ToString());
                    cmd.Parameters.AddWithValue("@Idx", member.Idx);

                    cmd.ExecuteNonQuery();
                    Console.ReadKey();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("MemberDAO UpdateAdmin" + ex.Message);
            }
        }

        //회원,비회원 정보 수정
        public void Update()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DataBase.Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    var query = @"UPDATE [dbo].[Member_Tbl]
                                        SET [Password]= @Password
                                           ,[Name]= @Name
                                           ,[Phone]= @Phone
                                           ,[Address]= @Address
                                           ,[Money]= @Money
                                        WHERE Idx = @Idx ";

                    cmd.CommandText = query;

                    cmd.Parameters.AddWithValue("@Password", member.Password);
                    cmd.Parameters.AddWithValue("@Name", member.Name);
                    cmd.Parameters.AddWithValue("@Phone", member.Phone);
                    cmd.Parameters.AddWithValue("@Address", member.Address);
                    cmd.Parameters.AddWithValue("@Money", member.Money);
                    cmd.Parameters.AddWithValue("@Idx", member.Idx);

                    cmd.ExecuteNonQuery();
                    Console.ReadKey();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("MemberDAO Update"+ex.Message);
            }
        }

        //Idx로 회원,비회원 검색
        public void Search()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DataBase.Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    var query = "SELECT * FROM [dbo].[Member_Tbl] " +
                            " WHERE [Idx] = @Idx ";
                    cmd.CommandText = query;

                    cmd.Parameters.AddWithValue("@Idx", member.Idx);

                    SqlDataReader reader = cmd.ExecuteReader();

                    string[] datas = new string[reader.FieldCount];
                    if (reader.Read())
                    {
                        for (int i = 0; i < reader.FieldCount; i++)
                            datas[i] = reader.GetValue(i).ToString();

                        member.Idx = int.Parse(datas[0]);
                        member.Id = datas[1];
                        member.Password = datas[2];
                        member.Name = datas[3];
                        member.Phone = datas[4];
                        member.Address = datas[5];
                        member.SeatNum = int.Parse(datas[6]);
                        member.Money = int.Parse(datas[7]);
                        member.RemainingTime = int.Parse(datas[8]);
                        member.IsMember = bool.Parse(datas[9]);
                        member.RegDate = datas[10];
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("MemberDAO Search" + ex.Message);
            }
        }

        //전체 회원 정보 불러와서 memberList에 저장
        public void SearchAll()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DataBase.Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    var query = "SELECT * FROM [dbo].[Member_Tbl] ";
                    cmd.CommandText = query;

                    SqlDataReader reader = cmd.ExecuteReader();

                    string[] datas = new string[reader.FieldCount];

                    List<MemberDTO> memberList = new List<MemberDTO>();
                    while (reader.Read())
                    {
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            datas[i] = reader.GetValue(i).ToString();
                        }

                        MemberDTO member = new MemberDTO();
                        member.Idx = int.Parse(datas[0]);
                        member.Id = datas[1];
                        member.Password = datas[2];
                        member.Name = datas[3];
                        member.Phone = datas[4];
                        member.Address = datas[5];
                        member.SeatNum = int.Parse(datas[6]);
                        member.Money = int.Parse(datas[7]);
                        member.RemainingTime = int.Parse(datas[8]);
                        member.IsMember = bool.Parse(datas[9]);
                        member.RegDate = datas[10];


                        memberList.Add(member);
                    }
                    this.memberList = memberList;

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("MemberDAO SearchAll" + ex.Message);
            }
        }

        //회원탈퇴, 삭제
        public void Delete()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DataBase.Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    var query = "";

                    query = "DELETE FROM [dbo].[Member_Tbl] " +
                            " WHERE [Idx] = @Idx ";
                    cmd.CommandText = query;

                    cmd.Parameters.AddWithValue("@Idx", member.Idx);

                    var result = cmd.ExecuteNonQuery();
                    if (result == 1)
                    {
                        Console.WriteLine("-- 회원 삭제 성공 --");
                    }
                    else
                    {
                        Console.WriteLine("-- 회원 삭제 실패 --");
                    }
                    Console.ReadKey();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("MemberDAO Delete" + ex.Message);
            }
        }
    }
}

