﻿namespace PC_Room.Member
{
    class MemberDTO
    {
        public MemberDTO() { }

        //비회원
        public MemberDTO(string id, int money)
        {
            Id = id;
            Money = money;
            IsMember = false;
        }

        //회원가입
        public MemberDTO(string id, string password, string name, string phone, string address, int money)
        {
            Id = id;
            Password = password;
            Name = name;
            Phone = phone;
            Address = address;
            Money = money;
            IsMember = true;
        }

        public int Idx { get; set; }            //번호
        public string Id { get; set; }          //아이디
        public string Password { get; set; }    //비밀번호
        public string Name { get; set; }        //이름
        public string Phone { get; set; }       //연락처
        public string Address { get; set; }     //주소
        public int SeatNum { get; set; }        //좌석번호
        public int Money { get; set; }          //소지금
        public int RemainingTime { get; set; }  //남은시간
        public bool IsMember { get; set; }      //회원여부
        public string RegDate { get; set; }     //가입날짜
    }
}
