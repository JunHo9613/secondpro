﻿using PC_Room.Interface;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PC_Room.Member
{
    class MemberManager : ManagerInterface
    {
        public List<MemberDTO> memberList;
        MemberDAO memberDAO = new MemberDAO();
        public MemberDTO member { get; set; }


        //회원 정보 출력
        public void PrintMember()
        {
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
            Console.WriteLine($"번호\t\t : {member.Idx}");
            Console.WriteLine($"아이디\t\t : {member.Id}");
            Console.WriteLine($"비밀번호\t : {member.Password}");
            Console.WriteLine($"이름\t\t : {member.Name}");
            Console.WriteLine($"전화\t\t : {member.Phone}");
            Console.WriteLine($"주소\t\t : {member.Address}");
            Console.WriteLine($"좌석\t\t : {member.SeatNum}");
            Console.WriteLine($"소지금\t\t : {member.Money}");
            Console.WriteLine($"남은시간\t : {member.RemainingTime}");
            Console.WriteLine($"회원여부\t : {member.IsMember}");
            Console.WriteLine($"등록일\t : {member.RegDate}");
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
            Console.WriteLine();
        }

        //비회원 생성
        public MemberDTO NonMember()
        {
            Random rand = new Random();

            while (true)
            {
                Console.WriteLine("회원추가");
                Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
                string id = "NonMember"+(rand.Next(99999999) + 100).ToString();
                Console.Write("소지금\t\t >> ");
                string money = Console.ReadLine();

                if (string.IsNullOrEmpty(id) || string.IsNullOrEmpty(money))
                {
                    Console.WriteLine("빈값은 입력할 수 없습니다.");
                    Console.ReadLine();
                    continue;
                }
                else
                {
                    member = new MemberDTO(id,int.Parse(money));
                    memberDAO.member = this.member;
                    memberDAO.Insert();
                    Console.WriteLine("비회원 로그인 성공");
                    Console.ReadLine();

                    //데이터베이스에 저장된 비회원 정보값 불러옴
                    SearchId();
                    this.member = memberDAO.member;
                    return member;
                }
            }

        }

        //회원 추가
        public void Add()
        {
            while (true)
            {
                Console.WriteLine("회원추가");
                Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
                Console.Write("아이디\t\t >> ");
                string id = Console.ReadLine();
                Console.Write("비밀번호\t >> ");
                string password = Console.ReadLine();
                Console.Write("이름\t\t >> ");
                string name = Console.ReadLine();
                Console.Write("연락처\t\t >> ");
                string phone = Console.ReadLine();
                Console.Write("주소\t\t >> ");
                string address = Console.ReadLine();
                Console.Write("소지금\t\t >> ");
                string money = Console.ReadLine();

                if (string.IsNullOrEmpty(id) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(name) || string.IsNullOrEmpty(phone) || string.IsNullOrEmpty(address) || string.IsNullOrEmpty(money))
                {
                    Console.WriteLine("빈값은 입력할 수 없습니다.");
                    Console.ReadLine();
                    continue;
                }
                MemberDTO member = new MemberDTO(id, password, name, phone, address, int.Parse(money));
                memberDAO.member = member;
                memberDAO.Insert();
                break;
            }
        }

        //자리 정보 변경
        public void UpdateSeatNum()
        {
            memberDAO.member = member;
            memberDAO.UpdateSeatNum();
            SearchId();
        }

        //사용료 결제 후 소지금+남은시간 변경
        public void UpdateUsageFee()
        {
            memberDAO.member = member;
            memberDAO.UpdateUsageFee();
            SearchId();
        }

        //상점 결제 후 소지금 변경
        public void UpdateBuy()
        {
            memberDAO.member = member;
            memberDAO.UpdateBuy();
            SearchId();
        }

        //마이페이지에서 수정
        public void UpdateMyPage()
        {
            Console.WriteLine("회원수정");
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
            PrintMember();  //원본 정보 출력
            Console.WriteLine();
            Console.Write("비밀번호 재입력\t\t >> ");
            string uPassword = Console.ReadLine();
            Console.Write("이름 재입력\t\t >> ");
            string uName = Console.ReadLine();
            Console.Write("전화 재입력\t\t >> ");
            string uPhone = Console.ReadLine();
            Console.Write("주소 재입력\t\t >> ");
            string uAddress = Console.ReadLine();
            Console.Write("소지금 재입력\t\t >> ");
            string uMoney = Console.ReadLine();

            if (string.IsNullOrEmpty(uPassword)
                || string.IsNullOrEmpty(uName) || string.IsNullOrEmpty(uPhone)
                || string.IsNullOrEmpty(uAddress) || string.IsNullOrEmpty(uMoney))
            {
                Console.WriteLine("빈값은 입력할 수 없습니다.");
                Console.ReadLine();
            }
            else
            {
                member.Password = uAddress;
                member.Name = uName;
                member.Phone = uPhone;
                member.Address = uAddress;
                member.Money = int.Parse(uMoney);
                memberDAO.member = member;
                memberDAO.Update();
                memberDAO.Search();
                SearchId();
                this.member = memberDAO.member;
                PrintMember();
                Console.WriteLine("회원 정보가 수정되었습니다.");
                Console.ReadLine();
            }
        }

        //관리자 회원 검색 후 수정
        public void Update()
        {
            Console.WriteLine("회원수정");
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
            Console.Write("아이디 >> ");
            string id = Console.ReadLine();
            bool isFind = false;
            foreach (var member in memberList)
            {
                if (member.Id == id)
                {
                    isFind = true;

                    memberDAO.member = member;
                    memberDAO.Search();
                    this.member = memberDAO.member;
                    PrintMember();
                    Console.WriteLine();

                    Console.Write("아이디 재입력\t\t >> ");
                    string uId = Console.ReadLine();
                    Console.Write("비밀번호 재입력\t\t >> ");
                    string uPassword = Console.ReadLine();
                    Console.Write("이름 재입력\t\t >> ");
                    string uName = Console.ReadLine();
                    Console.Write("전화 재입력\t\t >> ");
                    string uPhone = Console.ReadLine();
                    Console.Write("주소 재입력\t\t >> ");
                    string uAddress = Console.ReadLine();
                    Console.Write("소지금 재입력\t\t >> ");
                    string uMoney = Console.ReadLine();

                    if (string.IsNullOrEmpty(uId) || string.IsNullOrEmpty(uPassword) 
                        || string.IsNullOrEmpty(uName) || string.IsNullOrEmpty(uPhone) 
                        || string.IsNullOrEmpty(uAddress) || string.IsNullOrEmpty(uMoney))
                    {
                        Console.WriteLine("빈값은 입력할 수 없습니다.");
                        Console.ReadLine();
                        continue;
                    }
                    else
                    {
                        member.Id = uId;
                        member.Password = uPassword;
                        member.Name = uName;
                        member.Phone = uPhone;
                        member.Address = uAddress;
                        member.Money = int.Parse(uMoney);
                        memberDAO.member = member;
                        memberDAO.UpdateAdmin();
                        memberDAO.Search();
                        this.member = memberDAO.member;
                        break;
                    }
                }
            }
            

            if (isFind == false)
            {
                Console.WriteLine("검색결과가 없습니다.");
            }
            SearchId();
            Console.ReadLine();
        }

        //관리자 회원 검색
        public void SearchMemer()
        {
            Console.WriteLine("회원검색");
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
            Console.Write("아이디 >> ");
            string id = Console.ReadLine();
            bool isFind = false;

            memberDAO.SearchAll();
            memberList = memberDAO.memberList;

            foreach (var m in memberList)
            {
                if (m.Id.Equals(id))
                {
                    isFind = true;
                    member = m;
                    break;
                }
            }

            if (!isFind)
            {
                Console.WriteLine("검색하신 회원을 찾을 수 없습니다.");
            }
            else PrintMember();

            Console.ReadKey();
        }

        //관리자 회원 검색 후 삭제
        public void DeleteMemer()
        {
            Console.WriteLine("회원삭제");
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
            Console.Write("아이디 >> ");
            string id = Console.ReadLine();
            bool isFind = false;

            memberDAO.SearchAll();
            memberList = memberDAO.memberList;

            foreach (var m in memberList)
            {
                if (m.Id.Equals(id))
                {
                    isFind = true;
                    member = m;
                    break;
                }
            }

            if (!isFind)
            {
                Console.WriteLine("검색하신 회원을 찾을 수 없습니다.");
            }
            else
            {
                Withdraw();
            }

            Console.ReadKey();
        }
        //회원 탈퇴
        public void Withdraw()
        {
            PrintMember();
            Console.Write("탈퇴 하시겠습니까? [y/n]");
            string answer = Console.ReadLine();
            if (answer.ToUpper() == "Y")
            {
                memberDAO.member = member;
                memberDAO.Delete();
            }
        }

        //회원 삭제
        public void Delete()
        {
            Console.WriteLine("회원삭제");
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
            Console.Write("아이디 >> ");
            string id = Console.ReadLine();

            bool isFind = false;

            foreach (var member in memberList)
            {
                if (member.Id == id)
                {
                    isFind = true;
                    memberDAO.member = member;
                    memberDAO.Search();
                    this.member = memberDAO.member;
                    PrintMember();
                    Console.Write("선택한 회원을 삭제하시겠습니까? [y/n]");
                    string answer = Console.ReadLine(); // y/n
                    if (answer.ToUpper() == "Y")
                    {
                        memberDAO.member = member;
                        memberDAO.Delete();
                    }

                    break;
                }
            }

            if (isFind == false)
            {
                Console.WriteLine("검색결과가 없습니다.");
            }

            Console.ReadLine();
        }

        //전체 회원 조회
        public void PrintList()
        {
            Console.WriteLine("회원전체 출력");
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");

            if (memberList.Count == 0)
            {
                Console.WriteLine("등록된 회원이 없습니다.");
            }
            else
            {
                memberDAO.SearchAll();
                memberList = memberDAO.memberList;
                
                foreach(var member in memberList)
                {
                    this.member = member;
                    PrintMember();
                }
            }
            Console.ReadLine();
        }

        //회원 ID 입력 받아 검색
        public void Search()
        {
           string id = Console.ReadLine();
            memberDAO.SearchAll();
            memberList = memberDAO.memberList;

            foreach (var member in memberList)
            {
                if (member.Id == id)
                {
                    memberDAO.member = member;
                    memberDAO.Search();
                    this.member = member;
                    break;
                }
            }
            Console.ReadLine();
        }

        //저장된 member의 ID를 검색
        public void SearchId()
        {
            memberDAO.SearchAll();
            memberList = memberDAO.memberList;

            foreach (var m in memberList)
            {
                if (member.Id == m.Id)
                {
                    memberDAO.member = m;
                    memberDAO.Search();
                    this.member = memberDAO.member;
                    break;
                }
            }
        }
    }
}
