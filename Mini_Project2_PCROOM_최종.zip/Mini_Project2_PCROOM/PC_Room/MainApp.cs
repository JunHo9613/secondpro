﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PC_Room
{
    class MainApp
    {
        static void Main(string[] args)
        {
            PC_Room pc_Room = new PC_Room();
            pc_Room.MainLoop();
        }
    }
}
