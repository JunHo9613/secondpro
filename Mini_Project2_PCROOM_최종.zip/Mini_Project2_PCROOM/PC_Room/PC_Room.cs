﻿using PC_Room.CustomerService;
using PC_Room.Member;
using PC_Room.Menu;
using System;
using System.Collections.Generic;
using CustomerServiceClient;
using System.Media;

namespace PC_Room
{
    //PC방
    class PC_Room
    {
        //현재 멤버
        MemberDTO currentMember = new MemberDTO();
        MemberDAO memberDAO = new MemberDAO();

        //채팅
        Chatting chatting = new Chatting();

        string On = @"C:\Users\bitcamp\Desktop\Mini_Project2_PCROOM\PC_Room\bin\Debug\키는소리.wav";
        string Off = @"C:\Users\bitcamp\Desktop\Mini_Project2_PCROOM\PC_Room\bin\Debug\끄는소리.wav";
        

        public void PrintTitle()
        {
            SoundPlayer player = new SoundPlayer(On);
            player.PlaySync();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("                                                                                    ");
            Console.WriteLine("                                                                                    ");
            Console.WriteLine("   ▦▦▦▦▦        ▦▦▦     ▦▦▦▦▦▦               ▦▦▦▦▦         ▦▦▦▦ ");
            Console.WriteLine("   ▦        ▦        ▦            ▦                    ▦       ▦       ▦        ");
            Console.WriteLine("   ▦         ▦       ▦            ▦                    ▦       ▦      ▦         ");
            Console.WriteLine("   ▦        ▦        ▦            ▦                    ▦▦▦▦▦       ▦         ");
            Console.WriteLine("   ▦   ▦▦▦         ▦            ▦                    ▦               ▦         ");
            Console.WriteLine("   ▦        ▦        ▦            ▦                    ▦               ▦         ");
            Console.WriteLine("   ▦         ▦       ▦            ▦                    ▦               ▦         ");
            Console.WriteLine("   ▦        ▦        ▦            ▦                    ▦                ▦        ");
            Console.WriteLine("   ▦▦▦▦▦        ▦▦▦          ▦                    ▦                 ▦▦▦▦ ");
            Console.WriteLine("                                                                                    ");
            Console.WriteLine("            ▦▦▦▦▦        ▦▦▦▦         ▦▦▦▦          ▦▦     ▦▦    ");
            Console.WriteLine("            ▦       ▦      ▦      ▦       ▦      ▦        ▦  ▦   ▦  ▦   ");
            Console.WriteLine("            ▦       ▦     ▦        ▦     ▦        ▦      ▦   ▦   ▦   ▦  ");
            Console.WriteLine("            ▦▦▦▦▦      ▦        ▦     ▦        ▦      ▦    ▦ ▦    ▦  ");
            Console.WriteLine("            ▦    ▦        ▦        ▦     ▦        ▦     ▦     ▦▦      ▦ ");
            Console.WriteLine("            ▦     ▦       ▦        ▦     ▦        ▦     ▦      ▦       ▦ ");
            Console.WriteLine("            ▦      ▦      ▦        ▦     ▦        ▦     ▦      ▦       ▦ ");
            Console.WriteLine("            ▦       ▦      ▦      ▦       ▦      ▦      ▦      ▦       ▦ ");
            Console.WriteLine("            ▦       ▦       ▦▦▦▦         ▦▦▦▦       ▦      ▦       ▦ ");
            Console.ForegroundColor = ConsoleColor.White;
        }

        public void MainLoop()
        {
            try
            {
                MemberManager memberMng = new MemberManager
                {
                    memberList = new List<MemberDTO>()
                };

                while (true)
                {
                    Console.Clear();
                    //데이터베이스에서 읽어온 회원목록 저장
                    memberDAO.SearchAll();
                    memberMng.memberList = memberDAO.memberList;

                    //PC방 입장 타이틀 출력
                    PrintTitle();
                    Console.ReadLine();

                    //좌석선택
                    SeatMenu seatMenu = new SeatMenu(memberMng.memberList);
                    int seatNum = seatMenu.SelectSeat();
                    Console.Clear();

                    //메뉴선택
                    StartMenu startMenu = new StartMenu(memberMng);
                    int startMenuResult = startMenu.SelectMenu(seatNum);
                    currentMember = startMenu.currentMember;
                    Console.Clear();

                    //프로그램 종료
                    if (startMenuResult == 0)
                    {
                        SoundPlayer player = new SoundPlayer(Off);
                        player.PlaySync();
                        return;
                    }
                    //처음으로
                    else if (startMenuResult == 1) continue;
                    //회원 또는 비회원으로 로그인 / 회원 메인
                    else if(startMenuResult == 2)
                    {
                        //회원 메인 메뉴(마이페이지, 사용료결제, 처음으로, 종료)
                        MemberMainMenu memberMainMenu = new MemberMainMenu(memberMng);
                        memberMainMenu.currentMember = currentMember;
                        memberMainMenu.chatting = chatting;
                        int mainMenuResult = memberMainMenu.SelectMenu();
                        if (mainMenuResult == 0) return;
                        else  continue;
                    }
                    else if (startMenuResult == 3)//관리자 로그인 / 관리자 메인
                    {
                        //관리자 메인 메뉴(회원관리, 상품관리, 처음으로, 종료)
                        AdminMainMenu adminMainMenu = new AdminMainMenu(memberMng);
                        adminMainMenu.chatting = chatting;
                        int adminMainMenuResult = adminMainMenu.SelectMenu();
                        if (adminMainMenuResult == 0) return;
                        else continue;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"예외발생 : {ex.Message}");
            }
        }
    }
}
