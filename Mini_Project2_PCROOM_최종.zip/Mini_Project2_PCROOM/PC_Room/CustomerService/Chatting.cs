﻿using PC_Room.Member;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PC_Room.CustomerService
{
    class Chatting
    {
        public bool isAdmin { get; set; }
        public MemberDTO member { get; set; }
        public MemberManager memberMng { get; set; }
        public int menuNum { get; set; }

        public Chatting() { }

        const string IP = "127.0.0.1";
        const int PORT = 9000;

        static string myId = "";
        static string whisperId = "";

        static Socket clientSocket = null;
        static IPEndPoint ipep = null;


        public int ClientConnect()
        {
            clientSocket = new Socket(AddressFamily.InterNetwork,
                                      SocketType.Stream,
                                      ProtocolType.Tcp);

            ipep = new IPEndPoint(IPAddress.Parse(IP), PORT);

            clientSocket.Connect(ipep);


            //관리자 채팅
            if (isAdmin) { return AdminChat(); }
            //회원 채팅
            else { return MemberChat(); }
        }

        //회원 채팅
        public int MemberChat()
        {
            myId = member.Id;
            MemberMessage();
            return 1;
        }

        //회원 채팅
        public void MemberMessage()
        {
            String packet = "";

            NetworkStream ns = new NetworkStream(clientSocket);
            StreamWriter sw = new StreamWriter(ns);
            StreamReader sr = new StreamReader(ns);

            Thread thread = new Thread(new ParameterizedThreadStart(threadRead));
            thread.Start(clientSocket);

            while (true)
            {
                Console.WriteLine("'exit'를 입력하면 채팅이 종료 됩니다. >>>>>>>>>> ");
                String msg = Console.ReadLine();
                if (msg == "exit") break;

                //C : 채팅 | 아이디 | 메세지
                packet = String.Format("M|{0}|{1}", myId, msg);
                sw.WriteLine(packet);
                sw.Flush();
            }

            clientSocket.Close();
        }

        //관리자 채팅
        public int AdminChat()
        {
            if (menuNum == 1) AdminAllMessage();
            else if (menuNum == 2) AdminWhisperMessage();
            else AdminIdList();
            return 2;
        }

        //관리자 전체메세지
        public void AdminAllMessage()
        {
            String packet = "";

            NetworkStream ns = new NetworkStream(clientSocket);
            StreamWriter sw = new StreamWriter(ns);
            StreamReader sr = new StreamReader(ns);

            Thread thread = new Thread(new ParameterizedThreadStart(threadRead));
            thread.Start(clientSocket);

            while (true)
            {
                Console.WriteLine("'exit'를 입력하면 채팅이 종료 됩니다. >>>>>>>>>> ");
                Console.Write("메세지 입력 : ");
                String msg = Console.ReadLine();
                if (msg == "exit") break;

                //A:관리자 | 아이디 | 전체메세지 | 메세지
                packet = String.Format("A|{0}|A|{1}", myId, msg);
                sw.WriteLine(packet);
                sw.Flush();
            }

            clientSocket.Close();
        }

        //관리자 개인 메세지
        public void AdminWhisperMessage()
        {
            NetworkStream ns = new NetworkStream(clientSocket);
            StreamWriter sw = new StreamWriter(ns);
            StreamReader sr = new StreamReader(ns);

            String response = sr.ReadLine();
            String[] dataArr = response.Split(new char[] { '|' });
            String mainCmd = dataArr[0];
            String subCmd = dataArr[1];
            string packet;

            if (mainCmd == "A")
            {
                if (subCmd == "F")
                {
                    Console.WriteLine("-- [오류] --");
                    Console.ReadKey();
                }

                Console.Write("수신 아이디 입력 >> ");
                whisperId = Console.ReadLine();
                whisperId = FindWhisperId(dataArr, whisperId);

                if (whisperId != "")
                {
                    Thread thread = new Thread(new ParameterizedThreadStart(threadRead));
                    thread.Start(clientSocket);

                    while (true)
                    {
                        Console.WriteLine("'exit'입력시 채팅이 종료 됩니다. >>>>>>>>>> ");
                        String msg = Console.ReadLine();
                        if (msg == "exit")
                            break;

                        //A:관리자 | 아이디 | W:개인메세지 | 받는아이디 | 메세지 
                        packet = String.Format("A|{0}|W|{1}|{2}", myId, whisperId, msg);
                        sw.WriteLine(packet);
                        sw.Flush();
                    }
                    clientSocket.Close();
                }
                else
                {
                    Console.WriteLine("회원을 찾지 못했습니다. 아이디를 다시 확인해주세요.");
                }
            }
        }

        //접속된 아이디 리스트
        public void AdminIdList()
        {
            NetworkStream ns = new NetworkStream(clientSocket);
            StreamWriter sw = new StreamWriter(ns);
            StreamReader sr = new StreamReader(ns);

            String response = sr.ReadLine();
            String[] dataArr = response.Split(new char[] { '|' });
            String mainCmd = dataArr[0];
            String subCmd = dataArr[1];
            string packet;

            //A:관리자 | 아이디 | L:리스트 
            packet = "A|L";
            sw.WriteLine(packet);
            sw.Flush();

            packet = sr.ReadLine();
            dataArr = packet.Split(new char[] { '|' });
            mainCmd = dataArr[0];
            subCmd = dataArr[1];

            Console.WriteLine("---ID 리스트---");
            for (int i = 2; i < dataArr.Length; i++)
            {
                Console.WriteLine(dataArr[i]);
            }
            Console.WriteLine();
        }

        //접속된 회원을 아이디로 찾기
        public string FindWhisperId(string[] idArr, string whisperId)
        {
            string findId = "";
            foreach (string id in idArr)
            {
                if (id == whisperId)
                {
                    findId = whisperId;
                    break;
                }
            }

            return findId;
        }

        //나가기
        public void runExit(Socket clientSocket)
        {
            String packet = "E|";

            NetworkStream ns = new NetworkStream(clientSocket);
            StreamWriter sw = new StreamWriter(ns);
            sw.WriteLine(packet);
            sw.Flush();
        }


        public void threadRead(object sock)
        {
            Socket clientSocket = (Socket)sock;
            NetworkStream ns = new NetworkStream(clientSocket);
            StreamReader sr = new StreamReader(ns);

            try
            {
                while (true)
                {
                    String strMsg = sr.ReadLine();
                    processChat(strMsg);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("[클라이언트] : 채팅 종료");
                if (sr != null) sr.Close();
                if (ns != null) ns.Close();
                if (clientSocket != null) clientSocket.Close();
            }
        }

        public void processChat(string msg)
        {
            bool isRun = true;
            while (isRun)
            {
                NetworkStream ns = new NetworkStream(clientSocket);
                StreamWriter sw = new StreamWriter(ns);
                Console.WriteLine();
                Console.WriteLine("Chatting.cs processChat msg : " + msg);
                string mgs = Console.ReadLine();
                string packet = $"M|O|{mgs}";
                string[] dataArr = msg.Split(new char[] { '|' });
                string mainCmd = dataArr[0];
                string sendId = dataArr[1];
                sw.WriteLine(packet);
                sw.Flush();
                Console.ReadKey();

                switch (mainCmd)
                {
                    case "A":

                    case "M":
                        Console.WriteLine("{0}\t\t>> {1}", sendId, dataArr[2]);
                        break;
                    case "L":
                        Console.WriteLine("---ID 리스트---");

                        for (int i = 2; i < dataArr.Length; i++)
                        {
                            Console.WriteLine(dataArr[i]);
                        }
                        Console.WriteLine();
                        break;
                }
            }
        }
    }
}