﻿using PC_Room.DataBase;
using PC_Room.Member;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PC_Room
{
    //스타트 메뉴(로그인, 비회원 회원가입, 메인화면, 종료)
    class StartMenu
    {
        public MemberManager memberMng { get; set; }
        public MemberDTO currentMember { get; set; }
        MemberDAO memberDAO = new MemberDAO();

        public StartMenu(MemberManager memberMng)
        {
            this.memberMng = memberMng;
        }

        public MemberDTO getMember()
        {
            return currentMember;
        }

        //메뉴 출력
        public void PrintMenu()
        {
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
            Console.WriteLine();
            Console.WriteLine("\t\t\t\t ▒▒▒▒▒▒▒▒  메    뉴 ▒▒▒▒▒▒▒▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t1. 로  그  인 \t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t             \t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t2. 비 회 원 시 작  ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t3. 회 원 가 입\t   ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t4. 메 인 화 면\t   ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t5. 전 체 종 료\t   ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒");
            Console.WriteLine();
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
        }

        //메뉴 선택
        public int SelectMenu(int seatNum)
        {
            while (true)
            {
                Console.Clear();
                //메뉴 출력
                PrintMenu();

                //메뉴 선택
                Console.Write("선택 >> ");
                int menuNum = int.Parse(Console.ReadLine());

                if (menuNum < 0 || menuNum > 5)
                {
                    Console.WriteLine("[입력오류!] 다시 입력하세요.");
                    continue;
                }

                Console.Clear();

                switch (menuNum)
                {
                    case 1: //로그인
                        Login login = new Login(memberMng.memberList);
                        //관리자 로그인(admin/1234)
                        if (login.IsLogin(seatNum) == 1)
                        {
                            return 3;
                        }
                        //회원 로그인
                        if (login.IsLogin(seatNum) == 2)
                        {
                            currentMember = login.getmember();
                            Console.WriteLine(currentMember.Name + "님 환영합니다.");
                            Console.ReadLine();
                            memberMng.member = currentMember;
                            memberMng.UpdateSeatNum();
                            memberMng.PrintMember();
                            return 2;
                        }
                        //아이디 비밀번호 일치하지 않을 경우
                        else break;
                    case 2: // 비회원으로 시작
                        currentMember = memberMng.NonMember();
                        Console.WriteLine(currentMember.Name + "님 환영합니다.");
                        Console.ReadLine();
                        currentMember.SeatNum = seatNum;
                        memberMng.member = currentMember;
                        memberMng.UpdateSeatNum();
                        memberMng.PrintMember();
                        return 2;
                    case 3: // 회원가입
                        memberMng.Add();
                        continue;
                    case 4: // 처음으로
                        Console.WriteLine("메인화면으로 돌아갑니다.");
                        Console.ReadLine();
                        return 1;
                    case 5: // 종료
                        Console.WriteLine("프로그램을 종료합니다.");
                        Console.ReadLine();
                        return 0;
                    default:
                        break;
                }
            }
        }
    }
}
