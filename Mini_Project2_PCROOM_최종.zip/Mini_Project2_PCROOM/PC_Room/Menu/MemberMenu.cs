﻿using PC_Room.Member;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PC_Room.Menu
{
    class MemberMenu
    {
        public MemberManager memberMng { get; set; }

        //회원 메뉴 선택지 출력
        public void PrintMenu()
        {
            Console.WriteLine(); Console.WriteLine();
            Console.WriteLine("\t\t\t\t ▒▒▒▒▒▒▒▒  메    뉴 ▒▒▒▒▒▒▒▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t1. 회 원 정 보\t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t             \t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t2. 회 원 수 정\t   ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t3. 회 원 탈 퇴\t   ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t4. 메 인 화 면\t   ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t5. 전 체 종 료\t   ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒");
        }

        //회원 메뉴 선택
        public int SelectMenu()
        {
            while (true)
            {
                Console.Clear();
                PrintMenu();

                //메뉴 선택
                Console.Write("선택 >> ");
                int menuNum = int.Parse(Console.ReadLine());

                if (menuNum < 0 || menuNum > 5)
                {
                    Console.WriteLine("[입력오류!] 다시 입력하세요.");
                    continue;
                }

                Console.Clear();

                switch (menuNum)
                {
                    case 1: //회원정보
                        memberMng.PrintMember();
                        break;
                    case 2: // 회원수정
                        memberMng.UpdateMyPage();
                        memberMng.PrintMember();
                        break;
                    case 3: // 회원탈퇴
                        memberMng.Withdraw();
                        return 1;
                    case 4: //메인화면
                        Console.WriteLine("메인화면으로 돌아갑니다.");
                        Console.ReadLine();
                        return 1;
                    case 5: // 종료
                        Console.WriteLine("프로그램을 종료합니다.");
                        Console.ReadLine();
                        return 0;
                    default:
                        break;
                }
            }
        }



        //관리자 회원관리 선택지 출력
        public void PrintMenu_Admin()
        {
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
            Console.WriteLine("1. 회원추가");
            Console.WriteLine("2. 회원수정");
            Console.WriteLine("3. 회원검색");
            Console.WriteLine("4. 전체회원");
            Console.WriteLine("5. 회원삭제");
            Console.WriteLine("6. 메인화면");
            Console.WriteLine("7. 종료");
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
        }

        //회원 메뉴 선택
        public int SelectMenu_Admin()
        {
            while (true)
            {
                Console.Clear();
                PrintMenu_Admin();

                //메뉴 선택
                Console.Write("선택 >> ");
                int menuNum = int.Parse(Console.ReadLine());

                if (menuNum < 0 || menuNum > 5)
                {
                    Console.WriteLine("[입력오류!] 다시 입력하세요.");
                    continue;
                }

                Console.Clear();

                switch (menuNum)
                {
                    case 1: //회원추가
                        memberMng.Add();
                        break;
                    case 2: // 회원수정
                        memberMng.Update();
                        memberMng.PrintMember();
                        break;
                    case 3: //회원검색
                        memberMng.SearchMemer();
                        break;
                    case 4: // 전체회원
                        memberMng.PrintList();
                        break;
                    case 5: // 회원탈퇴
                        memberMng.DeleteMemer();
                        break;
                    case 6: //메인화면
                        Console.WriteLine("메인화면으로 돌아갑니다.");
                        Console.ReadLine();
                        return 1;
                    case 7: // 종료
                        Console.WriteLine("프로그램을 종료합니다.");
                        Console.ReadLine();
                        return 0;
                }
            }
        }
    }
}
