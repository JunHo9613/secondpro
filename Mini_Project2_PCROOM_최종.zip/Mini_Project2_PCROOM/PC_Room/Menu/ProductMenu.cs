﻿using PC_Room.Product;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PC_Room.Menu
{

    class ProductMenu
    {
        public ProductMenu(ProductManager productMng)
        {
            ProductMng = productMng;
        }

        public ProductManager ProductMng { get; set; }

        public void PrintMenu()
        {
            Console.WriteLine(); Console.WriteLine();
            Console.WriteLine("\t\t\t\t ▒▒▒▒▒▒▒▒  메    뉴 ▒▒▒▒▒▒▒▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t1. 상 품 추 가\t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t             \t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t2. 상 품 수 정\t   ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t3. 상 품 검 색\t   ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t4. 전 체 상 품\t   ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t5. 상 품 삭 제\t   ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t6. 메 인 화 면\t   ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t7. 전 체 종 료\t   ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒");
        }

        internal int SelectMenu()
        {
            while (true)
            {
                Console.Clear();
                PrintMenu();

                //메뉴 선택
                Console.Write("선택 >> ");
                int menuNum = int.Parse(Console.ReadLine());

                if (menuNum < 0 || menuNum > 7)
                {
                    Console.WriteLine("[입력오류!] 다시 입력하세요.");
                    continue;
                }

                Console.Clear();

                switch (menuNum)
                {
                    case 1: //상품추가
                        ProductMng.Add();
                        ProductMng.PrintProduct();
                        Console.ReadKey();
                        break;
                    case 2: // 상품수정
                        ProductMng.Update();
                        ProductMng.PrintProduct();
                        Console.ReadKey();
                        break;
                    case 3: // 상품검색
                        ProductMng.Search();
                        return 1;
                    case 4: // 전체상품
                        ProductMng.PrintList();
                        break;
                    case 5: // 상품삭제
                        ProductMng.Delete();
                        break;
                    case 6: //메인화면
                        Console.WriteLine("메인화면으로 돌아갑니다.");
                        Console.ReadLine();
                        return 1;
                    case 7: // 종료
                        Console.WriteLine("프로그램을 종료합니다.");
                        Console.ReadLine();
                        return 0;
                }
            }
        }
    }
}
