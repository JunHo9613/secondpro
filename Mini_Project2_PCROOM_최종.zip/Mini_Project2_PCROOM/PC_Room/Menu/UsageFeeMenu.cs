﻿using PC_Room.Member;
using PC_Room.UsageFeeReceipt;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PC_Room.Menu
{
    class UsageFeeMenu
    {
        public MemberDTO member { get; set; }
        MemberDAO memberDAO = new MemberDAO();
        MemberManager memberMng = null;

        public UsageFeeReceiptDTO usageFee { get; set; }
        UsageFeeReceiptDAO usageFeeDAO = new UsageFeeReceiptDAO();
        UsageFeeReceiptManager usageFeeMng = null;

        public UsageFeeMenu(MemberManager memberMng)
        {
            this.memberMng = memberMng;
            this.member = memberMng.member;
        }

        public UsageFeeMenu(MemberManager memberMng, UsageFeeReceiptManager usageFeeMng)
        {
            this.memberMng = memberMng;
            this.member = memberMng.member;
            this.usageFeeMng = usageFeeMng;
        }

        //회원 요금표 출력
        public void PrintMenu()
        {
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
            Console.WriteLine();
            Console.WriteLine("\t\t\t\t\t[\t요\t\t\t금\t]\t");
            Console.WriteLine("\n");
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
            Console.WriteLine("\t\t|\t\t회원\t\t|\t\t비회원");
            Console.WriteLine();
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
            Console.WriteLine("\t1. 1시간\t|\t\t1000원\t|\t\t1200원");
            Console.WriteLine("\t2. 2시간\t|\t\t1800원\t|\t\t2000원");
            Console.WriteLine("\t3. 3시간\t|\t\t2500원\t|\t\t3000원");
            Console.WriteLine("\t4. 5시간\t|\t\t4000원\t|\t\t5000원");
            Console.WriteLine("\t5. 10시간\t|\t\t7000원\t|\t\t10000원");
            Console.WriteLine("\t6. 메인화면");
            Console.WriteLine("\t7. 프로그램 종료");
        }

        //회원 요금 선택
        public int SelectMenu()
        {
            while (true)
            {
                Console.Clear();
                PrintMenu();
                
                //메뉴 선택
                Console.Write("선택 >> ");
                int select = int.Parse(Console.ReadLine());

                if (select < 0 || select > 7)
                {
                    Console.WriteLine("[입력오류!] 다시 입력하세요.");
                    Console.ReadLine();
                    continue;
                }

                if (select == 6)
                {
                    Console.WriteLine("메인화면으로 돌아갑니다.");
                    Console.ReadLine();
                    return 1;
                }
                else if (select == 7)
                {
                    Console.WriteLine("프로그램을 종료합니다.");
                    Console.ReadLine();
                    return 0;
                }

                Console.Clear();

                int payment = 0, time = 60;
                int receivedMoney = member.Money;
                int change = 0;

                //회원 요금
                if (member.IsMember)
                {
                    switch (select)
                    {
                        case 1: payment = 1000; time *= 1; break;
                        case 2: payment = 1800; time *= 2; break;
                        case 3: payment = 2500; time *= 3; break;
                        case 4: payment = 4000; time *= 5; break;
                        case 5: payment = 7000; time *= 10; break;
                    }
                }
                //비회원 요금
                else
                {
                    switch (select)
                    {
                        case 1: payment = 1200; time *= 1; break;
                        case 2: payment = 2000; time *= 2; break;
                        case 3: payment = 3000; time *= 3; break;
                        case 4: payment = 5000; time *= 5; break;
                        case 5: payment = 10000; time *= 10; break;
                    }
                }
                change = receivedMoney - payment;

                Console.ReadLine();

                //사용료 매니져 생성
                usageFeeMng = new UsageFeeReceiptManager(member, time, receivedMoney, payment, change);

                //비회원 정보 가져오기
                memberMng.member = member;
                memberMng.SearchId();
                member = memberMng.member;

                //고객의 소지금에서 결제금액 차감
                member.Money = change;
                //고객 남은 시간 충전
                member.RemainingTime += time;

                //데이터베이스에 바뀐 정보 업데이트
                memberMng.member = member;
                memberMng.UpdateUsageFee();

                usageFeeMng.member = member;
                //영수증 추가
                usageFeeMng.Add();

                //추가된 영수증 가져오기
                usageFeeMng.Search();

                //영수증+바뀐 회원정보 출력
                usageFeeMng.PrintUsageFee();
                memberMng.SearchId();
                memberMng.PrintMember();
                return 1;
            }
        }

        //관리자 메뉴 출력
        public void PrintMenu_Admin()
        {
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
            Console.WriteLine("관리자 메뉴 >> 사용료 매출 관리");
            Console.WriteLine("\t\t\t\t ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ ");
            Console.WriteLine("\t\t\t\t ▒\t             \t       ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t1. 사용료 전체 매출    ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t             \t       ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t2. V I P 확 인\t       ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t       ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t3. 사용료 영수증 검색  ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t       ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t4. 사용료 영수증 삭제  ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t       ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t5. 메 인 화 면 \t       ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t       ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t6. 전 체 종 료\t       ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t       ▒ ");
            Console.WriteLine("\t\t\t\t ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒");
        }

        //관리자 메뉴 선택
        public int SelectMenu_Admin()
        {
            while (true)
            {
                Console.Clear();
                PrintMenu_Admin();

                //메뉴 선택
                Console.Write("선택 >> ");
                int menuNum = int.Parse(Console.ReadLine());

                if (menuNum < 0 || menuNum > 6)
                {
                    Console.WriteLine("[입력오류!] 다시 입력하세요.");
                    Console.ReadLine();
                    continue;
                }

                Console.Clear();

                switch (menuNum)
                {
                    case 1: //사용료 전체매출
                        usageFeeMng.PrintList();
                        break;
                    case 2: // VIP 확인
                        usageFeeMng.VIPList();
                        break;
                    case 3: // 사용료 영수증 검색
                        Console.Write("회원 아이디 >> ");
                        memberMng.member.Id = Console.ReadLine();
                        memberMng.SearchId();
                        usageFeeMng.member = memberMng.member;
                        usageFeeMng.SearchId();
                        break;
                    case 4: // 사용료 영수증 검색
                        
                        break;
                    case 5: //메인화면
                        Console.WriteLine("메인화면으로 돌아갑니다.");
                        Console.ReadLine();
                        return 1;
                    case 6: // 종료
                        Console.WriteLine("프로그램을 종료합니다.");
                        Console.ReadLine();
                        return 0;
                }
            }
        }
    }
}
