﻿using CustomerServiceClient;
using PC_Room.CustomerService;
using PC_Room.Member;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PC_Room.Menu
{
    class ChatMenu
    {
        public MemberManager memberMng { get; set; }
        public string myId { get; set; }
        public Chatting chatting { get; set; }

        public ChatMenu() { }

        public void PrintMenu()
        {
            Console.WriteLine(); Console.WriteLine();
            Console.WriteLine("\t\t\t\t ▒▒▒▒▒▒▒▒  메    뉴 ▒▒▒▒▒▒▒▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t1. 전 체 메 세 지  ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t             \t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t2. 메 인 화 면\t   ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t3. 종 료 \t   ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒");
        }

        public int SelectMenu()
        {
            myId = "Admin";
            while (true)
            {
                Console.Clear();

                //메뉴 출력
                PrintMenu();

                //메뉴 선택
                Console.Write("선택 >> ");
                int menuNum = int.Parse(Console.ReadLine());

                if (menuNum < 0 || menuNum > 4)
                {
                    Console.WriteLine("[입력오류!] 다시 입력하세요.");
                    Console.ReadKey();
                    continue;
                }

                if (menuNum == 2) return 1;
                else if(menuNum == 3) return 0;
                else
                {
                    chatting.isAdmin = true;
                    chatting.menuNum = menuNum;
                    chatting.ClientConnect();
                }
            }
        }
    }
}
