﻿using CustomerServiceClient;
using PC_Room.CustomerService;
using PC_Room.Member;
using PC_Room.Product;
using PC_Room.UsageFeeReceipt;
using System;

namespace PC_Room.Menu
{
    class AdminMainMenu
    {
        //회원관리에 필요
        MemberManager memberMng = null;
        public MemberDTO currentMember { get; set; }
        //상품관리에 필요
        public ProductManager productMng = new ProductManager();
        //사용료 영수증 관리
        public UsageFeeReceiptManager usageFeeMng = new UsageFeeReceiptManager();
        //상점 구매 관리
        public StoreReceiptManager storeMng = new StoreReceiptManager();
        //채팅
        public Chatting chatting { get; set; }

        public AdminMainMenu(MemberManager memberMng)
        {
            this.memberMng = memberMng;
        }
        //메인 메뉴 선택지 출력
        public void PrintMenu()
        {
            Console.WriteLine(); Console.WriteLine();
            Console.WriteLine("\t\t\t\t ▒▒▒▒▒▒▒▒  메    뉴 ▒▒▒▒▒▒▒▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t1. 회 원 관 리\t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t             \t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t2. 상 품 관 리\t   ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t3. 사 용 료 매 출  ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t4. 상 점 매 출\t   ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t5. 채  팅 \t   ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t6. 메 인 화 면\t   ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t7. 전 체 종 료\t   ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t   ▒ ");
            Console.WriteLine("\t\t\t\t ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒");
        }

        public int SelectMenu()
        {
            while (true)
            {
                Console.Clear();
                PrintMenu();

                //메뉴 선택
                Console.Write("선택 >> ");
                int menuNum = int.Parse(Console.ReadLine());

                if (menuNum < 0 || menuNum > 7)
                {
                    Console.WriteLine("[입력오류!] 다시 입력하세요.");
                    continue;
                }

                Console.Clear();

                switch (menuNum)
                {
                    case 1: //회원관리
                        MemberMenu memberMenu = new MemberMenu();
                        memberMenu.memberMng = memberMng;
                        int memberMenuResult = memberMenu.SelectMenu_Admin();
                        if (memberMenuResult == 0) return 0;
                        else break;
                    case 2: // 상품관리
                         ProductMenu productMenu = new ProductMenu(productMng);
                        int productMenuResult = productMenu.SelectMenu();
                        if (productMenuResult == 0) return 0;
                        else break;
                    case 3: // 사용료매출
                        UsageFeeMenu usageFeeMenu = new UsageFeeMenu(memberMng, usageFeeMng);
                        int usageFeeMenuResult = usageFeeMenu.SelectMenu_Admin();
                        if (usageFeeMenuResult == 0) return 0;
                        else break;
                    case 4: // 상점매출
                        StoreMenu storeMenu = new StoreMenu(memberMng, productMng, storeMng);
                        int storeMenuResult = storeMenu.SelectMenu();
                        if (storeMenuResult == 0) return 0;
                        else break;
                    case 5: // 채팅
                        ChatMenu chatMenu = new ChatMenu();
                        chatMenu.chatting = chatting;
                        int chatMenuResult = chatMenu.SelectMenu();
                        if (chatMenuResult == 0) return 0;
                        else break;
                    case 6: //처음으로
                        Console.WriteLine("메인화면으로 돌아갑니다.");
                        Console.ReadLine();
                        return 1;
                    case 7: // 종료
                        Console.WriteLine("프로그램을 종료합니다.");
                        Console.ReadLine();
                        return 0;
                    default:
                        break;
                }
            }
        }
    }
}
