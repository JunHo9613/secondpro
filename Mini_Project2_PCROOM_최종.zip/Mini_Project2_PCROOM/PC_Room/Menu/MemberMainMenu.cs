﻿using CustomerServiceClient;
using PC_Room.CustomerService;
using PC_Room.Member;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PC_Room.Menu
{
    class MemberMainMenu
    {
        MemberManager memberMng = null;
        public MemberDTO currentMember { get; set; }
        public Chatting chatting { get; set; }

        public MemberMainMenu(MemberManager memberMng)
        {
            this.memberMng = memberMng;
        }

        //메인 메뉴 선택지 출력
        public void PrintMenu()
        {
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("\t\t\t\t ▒▒▒▒▒▒▒▒  메    뉴 ▒▒▒▒▒▒▒▒▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t    ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t1. MY PAGE \t    ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t             \t    ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t2. 사용료 결제\t    ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t    ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t3. PC 이용하기\t    ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t    ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t4. 메 인 화 면\t    ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t    ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t5. 종 료 \t    ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t    ▒ ");
            Console.WriteLine("\t\t\t\t ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒");
        }

        //메인 메뉴 선택
        public int SelectMenu()
        {
            while (true)
            {
                Console.Clear();
                PrintMenu();

                //메뉴 선택
                Console.Write("선택 >> ");
                int menuNum = int.Parse(Console.ReadLine());

                if (menuNum < 0 || menuNum > 4)
                {
                    Console.WriteLine("[입력오류!] 다시 입력하세요.");
                    continue;
                }

                Console.Clear();

                switch (menuNum)
                {
                    case 1: //마이페이지
                        MemberMenu memberMenu = new MemberMenu();
                        memberMenu.memberMng = memberMng;
                        int memberMenuResult = memberMenu.SelectMenu();
                        if (memberMenuResult == 0) return 0;
                        else break ;
                    case 2: // 사용료 결제
                        UsageFeeMenu usageFeeMenu = new UsageFeeMenu(memberMng);
                        int usageFeeMenuResult = usageFeeMenu.SelectMenu();
                        if (usageFeeMenuResult == 0) return 0;
                        else break;
                    case 3: // PC 이용하기
                        PCRoomMenu pcRoomMenu = new PCRoomMenu(memberMng);
                        pcRoomMenu.chatting = chatting;
                        int pcRoomMenuResult = pcRoomMenu.SelectMenu();
                        if (pcRoomMenuResult == 0) return 0;
                        else break;
                    case 4: //처음으로
                        Console.WriteLine("메인화면으로 돌아갑니다.");
                        Console.ReadLine();
                        return 1;
                    case 5: // 종료
                        Console.WriteLine("프로그램을 종료합니다.");
                        Console.ReadLine();
                        return 0;
                    default:
                        break;
                }
            }
        }
    }
}
