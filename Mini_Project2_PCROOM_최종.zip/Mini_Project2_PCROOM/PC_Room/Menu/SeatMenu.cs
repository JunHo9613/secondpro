﻿using PC_Room.Member;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PC_Room
{
    class SeatMenu
    {
        List<MemberDTO> memberList = new List<MemberDTO>();
        public SeatMenu(List<MemberDTO> memberList) 
        {
            this.memberList = memberList;
        }

        //좌석 사용가능여부 배열
        bool[] arrSeatNum = new bool[20];

        //전체 좌석 사용여부 확인 메서드
        public void IsSeat()
        {
            //초기화
            for (int i = 0; i < arrSeatNum.Length; i++)
            {
                arrSeatNum[i] = true;
            }

            for (int i = 0; i < memberList.Count; i++)
            {
                //사용 중인 자리는 false처리
                for (int j = 0; j < arrSeatNum.Length; j++)
                {
                    if (memberList[i].SeatNum - 1 == j)
                    {
                        arrSeatNum[j] = false;
                        break;
                    }
                }
            }
        }

        //전체 좌석 화면 출력
        public void PrintSeat()
        {
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
            Console.WriteLine();
            Console.WriteLine("\t\t\t\t\t[\t좌\t석\t확\t인\t]\t");
            Console.WriteLine("\n");
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");

            for (int i = 0; i < arrSeatNum.Length; i++)
            {
                if (i % 5 == 0) Console.WriteLine();
                if (!arrSeatNum[i])
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write($"[{i + 1}] 사용중\t\t");
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.Write($"[{i + 1}] 사용가능\t\t");
                }
                Console.ForegroundColor = ConsoleColor.White;
            }
            Console.WriteLine();
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
        }

        //좌석 선택
        public int SelectSeat()
        {
            while (true)
            {
                Console.Clear();
                //사용중인 좌석 확인
                IsSeat();
                //좌석 출력
                PrintSeat();

                Console.Write("좌석 선택 >>");
                int seatNum = int.Parse(Console.ReadLine());

                if ((seatNum < 1 || seatNum > 20))
                {
                    Console.WriteLine("1~20번 좌석 중 선택해주세요.");
                    Console.ReadLine();
                    continue;
                }
                if (!arrSeatNum[seatNum - 1])
                {
                    Console.WriteLine("사용할 수 없는 좌석입니다. 다시선택해주세요.");
                    Console.ReadLine();
                    continue;
                }

                return seatNum;
            }
        }
    }
}
