﻿namespace PC_Room.Menu
{
    public class StoreReceiptManager
    {
        public StoreReceiptManager()
        {
        }
    }
}