﻿using PC_Room.Member;
using PC_Room.Product;
using PC_Room.Store;
using System;
using System.Collections.Generic;

namespace PC_Room.Menu
{
    class StoreMenu
    {
        ProductManager productMng = new ProductManager();
        public MemberManager memberMng { get; set; }
        StoreManager storeMng = new StoreManager();
        private StoreReceiptManager storeMng1;

        public StoreMenu(){ }

        public StoreMenu(MemberManager memberMng, ProductManager productMng, StoreReceiptManager storeMng1)
        {
            this.memberMng = memberMng;
            this.productMng = productMng;
            this.storeMng1 = storeMng1;
        }

        public void PrintMenu()
        {
            Console.WriteLine(); Console.WriteLine();
            Console.WriteLine("\t\t\t\t ▒▒▒▒▒▒▒▒▒  메    뉴 ▒▒▒▒▒▒▒▒▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t     ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t1. 상점 메뉴 구경    ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t             \t     ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t2. 구 매 하 기       ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t     ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t3. 메 인 화 면 \t     ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t     ▒ ");
            Console.WriteLine("\t\t\t\t ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒");
        }
        public int SelectMenu()
        {
            while (true)
            {
                Console.Clear();
                PrintMenu();

                //메뉴 선택
                Console.Write("선택 >> ");
                int menuNum = int.Parse(Console.ReadLine());

                if (menuNum < 0 || menuNum > 4)
                {
                    Console.WriteLine("[입력오류!] 다시 입력하세요.");
                    continue;
                }

                Console.Clear();

                switch (menuNum)
                {
                    case 1: //상품 카테고리 선택 후 목록 조회
                        productMng.Searchca();
                        break;
                    case 2: // 상품구매하기
                        storeMng.memberMng = memberMng;
                        storeMng.productMng = productMng;
                        storeMng.Add();
                        break;
                    case 3: //메인화면
                        Console.WriteLine("메인화면으로 돌아갑니다.");
                        Console.ReadLine();
                        return 1;
                    default:
                        continue;
                }
            }
        }
    }
}
