﻿using CustomerServiceClient;
using PC_Room.CustomerService;
using PC_Room.Member;
using System;

namespace PC_Room.Menu
{
    class PCRoomMenu
    {
        MemberDTO member = null;
        MemberManager memberMng = null;
        StoreMenu storeMenu = new StoreMenu();
        //ChatMenu chatMenu = new ChatMenu();
        public Chatting chatting { get; set; }

        public PCRoomMenu(MemberManager memberMng)
        {
            this.memberMng = memberMng;
            this.member = memberMng.member;
        }

        public void PrintMenu()
        {
            Console.WriteLine(); Console.WriteLine();
            Console.WriteLine("\t\t\t\t ▒▒▒▒▒▒▒▒  메    뉴 ▒▒▒▒▒▒▒▒▒▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t     ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t1. 상  점 \t     ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t             \t     ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t2. 고객센터(1:1문의) ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t     ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t3. 메 인 화 면\t     ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t     ▒ ");
            Console.WriteLine("\t\t\t\t ▒\t4. 종  료 \t     ▒");
            Console.WriteLine("\t\t\t\t ▒\t             \t     ▒ ");
            Console.WriteLine("\t\t\t\t ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒");
        }

        public int SelectMenu()
        {
            while (true)
            {
                //남은시간이 1분 미만이면 들어갈 수 없다.
                if (memberMng.member.RemainingTime < 1)
                {
                    Console.WriteLine("PC방 사용료를 결제 후 이용하실 수 있습니다.");
                    Console.ReadKey();
                    break;
                }

                Console.Clear();
                PrintMenu();

                //메뉴 선택
                Console.Write("선택 >> ");
                int menuNum = int.Parse(Console.ReadLine());

                if (menuNum < 0 || menuNum > 4)
                {
                    Console.WriteLine("[입력오류!] 다시 입력하세요.");
                    continue;
                }

                Console.Clear();

                switch (menuNum)
                {
                    case 1: //상점
                        storeMenu.memberMng = memberMng;
                        storeMenu.SelectMenu();
                        break;
                    case 2: //고객센터
                        //chatMenu.SelectMenu();
                        chatting.isAdmin = false;   //회원접속이니까 flase
                        chatting.member = member;
                        chatting.ClientConnect();   //채팅연결
                        break;
                    case 3: //메인화면
                        Console.WriteLine("메인화면으로 돌아갑니다.");
                        Console.ReadLine();
                        return 1;
                    case 4: // 종료
                        Console.WriteLine("프로그램을 종료합니다.");
                        Console.ReadLine();
                        return 0;
                }
            }

            return 1;
        }
    }
}
