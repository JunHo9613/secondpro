﻿using PC_Room.Member;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PC_Room
{
    class Login
    {
        List<MemberDTO> memberList = null;
        MemberDTO currentMember = new MemberDTO();
        MemberDAO memberDAO = new MemberDAO();

        public Login(List<MemberDTO> memberList)
        {
            this.memberList = memberList;
        }
        public int IsLogin(int seatNum)
        {
            string id, pw;

            while (true)
            {
                Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
                Console.WriteLine();
                Console.WriteLine("\t\t\t\t\t[\t로\t그\t인\t]\t");
                Console.WriteLine("\n");
                Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
                Console.Write("ID >> ");
                id = Console.ReadLine();
                Console.Write("Password >> ");
                pw = Console.ReadLine();

                if (string.IsNullOrEmpty(id) || string.IsNullOrEmpty(pw))
                {
                    Console.WriteLine("[입력오류] 아이디와 비밀번호를 모두 입력하세요.");
                    Console.ReadLine();
                    continue;
                }
                else break;
            }
            //관리자 로그인
            if (id.Equals("admin") && pw.Equals("1234"))
            {
                Console.WriteLine("관리자 로그인.");
                Console.ReadKey();
                return 1;
            }
            memberDAO.SearchAll();
            memberList = memberDAO.memberList;


            //입력된 아이디와 비밀번호가 일치하는 회원이 있는지 확인
            foreach (var member in memberList)
            {
                if (member.Id == id && member.Password == pw)
                {
                    member.SeatNum = seatNum;
                    currentMember = member;
                    return 2;
                }
            }

            Console.WriteLine("아이디와 비밀번호가 일치하지 않습니다.");
            Console.WriteLine();
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------");
            Console.ReadLine();
            return 0;
        }

        public MemberDTO getmember()
        {
            return currentMember;
        }
    }
}
