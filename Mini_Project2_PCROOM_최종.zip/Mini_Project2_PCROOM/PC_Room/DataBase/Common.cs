﻿using System.Net;

namespace PC_Room.DataBase
{
    class Common
    {
        public static string ConnString = "Data Source=localhost;Initial Catalog=PCRoom_DB;Persist Security Info=True;User ID=Test_Login;Password=p1234";

    }
}
