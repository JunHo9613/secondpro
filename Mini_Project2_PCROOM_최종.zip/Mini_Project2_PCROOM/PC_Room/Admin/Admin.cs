﻿using PC_Room.DataBase;
using PC_Room.Member;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PC_Room
{
    //관리자
    class Admin
    {
        MemberDAO memberDAO = new MemberDAO();

        void AdminMember(MemberManager memberMng)
        {
            /*try
            {
                memberDAO.SearchAll();
                memberMng.memberList = memberDAO.memberList;

                while (true)
                {
                    Console.Clear();

                    memberMng.PrintMenu();
                    int menuNum = memberMng.SelectMenu();

                    switch (menuNum)
                    {
                        case 1: // 회원입력 화면 전환
                            Console.Clear();
                            memberMng.Add();
                            break;
                        case 2: // 회원검색
                            Console.Clear();
                            memberMng.Search();
                            break;
                        case 3: // 회원수정
                            Console.Clear();
                            memberMng.Update();
                            break;
                        case 4: // 회원삭제
                            Console.Clear();
                            memberMng.Delete();
                            break;
                        case 5: // 회원전체 출력
                            Console.Clear();
                            memberMng.PrintList();

                            break;
                        case 6: // 종료
                            Environment.Exit(0);
                            break;
                        default: // 0은 여기서처리
                                 // 아무 로직 없음
                            break;
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine($"예외발생 : {ex.Message}");
            }*/
        }
    }
}
