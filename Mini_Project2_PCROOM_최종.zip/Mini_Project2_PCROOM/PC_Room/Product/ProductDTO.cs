﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PC_Room.Product
{
    //상점에서 파는 상품
    class ProductDTO
    {
        public int Idx { get; set; }
        public string Category { get; set; }
        public string Name { get; set; }
        public int Price { get; set; }
        public int Stock { get; set; }
        public string RegDate { get; set; }

        public ProductDTO() { }

        public ProductDTO(string category, string name, int price, int stock)
        {
            this.Category = category;
            this.Name = name;
            this.Price = price;
            this.Stock = stock;
        }
    }
}
