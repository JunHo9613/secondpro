﻿using PC_Room.Interface;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PC_Room.Product
{
    class ProductDAO : SQLInterface
    {
        public string pName { get; set; }
        public string pCategory { get; set; }
        public ProductDTO product { get; set; }
        List<ProductDTO> productList = new List<ProductDTO>();

        public List<ProductDTO> getProductList()
        {
            return productList;
        }

        //상품 추가
        public void Insert()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DataBase.Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;
                    cmd.CommandText = @"INSERT INTO [dbo].[Product_Tbl]
                                                   ([Category]
                                                   ,[Name]
                                                   ,[Price]
                                                   ,[Stock])
                                             VALUES
                                                   (@카테고리
                                                   , @메뉴명
                                                   , @가격
                                                   , @재고량)";
                    cmd.Parameters.AddWithValue("@카테고리", product.Category);
                    cmd.Parameters.AddWithValue("@메뉴명", product.Name);
                    cmd.Parameters.AddWithValue("@가격", product.Price);
                    cmd.Parameters.AddWithValue("@재고량", product.Stock);

                    int Idx = cmd.ExecuteNonQuery();
                    Console.WriteLine(Idx + "행이 적용되었습니다");
                    Console.ReadKey();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("ProductDAO Insert" + ex.Message);
            }
        }
        //상품 수정
        public void Update()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DataBase.Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;
                    cmd.CommandText =
                        @"UPDATE [dbo].[Product_Tbl]
                             SET [Category] = @카테고리
                                ,[Name] = @상품명
                                ,[Price] = @가격
                                ,[Stock] = @재고
                           WHERE [Name] = @검색명";
                    cmd.Parameters.AddWithValue("@카테고리", product.Category);
                    cmd.Parameters.AddWithValue("@상품명", product.Name);
                    cmd.Parameters.AddWithValue("@가격", product.Price);
                    cmd.Parameters.AddWithValue("@재고", product.Stock);
                    cmd.Parameters.AddWithValue("@검색명", pName);

                    int Idx = cmd.ExecuteNonQuery();
                    Console.WriteLine(Idx + "행에 적용되었습니다");
                    Console.ReadKey();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("ProductDAO Update" + ex.Message);
            }
        }
        //재고수정
        public void UpdateStock()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DataBase.Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;
                    cmd.CommandText =
                        @"UPDATE [dbo].[Product_Tbl]
                             SET [Stock] = @재고
                           WHERE [Name] = @검색명";
                    cmd.Parameters.AddWithValue("@재고", product.Stock);
                    cmd.Parameters.AddWithValue("@검색명", product.Name);

                    int Idx = cmd.ExecuteNonQuery();
                    Console.ReadKey();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("ProductDAO UpdateStock" + ex.Message);
            }
        }
        //상품명 검색
        public void Search()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DataBase.Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    var query = "SELECT * FROM [dbo].[Product_Tbl] " +
                            " WHERE [Name] = @이름 ";

                    cmd.CommandText = query;

                    cmd.Parameters.AddWithValue("@이름", pName);

                    SqlDataReader reader = cmd.ExecuteReader();

                    string[] datas = new string[reader.FieldCount];
                    if (reader.Read())
                    {
                        for (int i = 0; i < reader.FieldCount; i++)
                            datas[i] = reader.GetValue(i).ToString();

                        product.Idx = int.Parse(datas[0]);
                        product.Category = datas[1];
                        product.Name = datas[2];
                        product.Price = int.Parse(datas[3]);
                        product.Stock = int.Parse(datas[4]);
                        product.RegDate = datas[5];
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("ProductDAO Search" + ex.Message);
            }
        }
        //카테고리 검색
        public void SearchCategory()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DataBase.Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    var query = "SELECT * FROM [dbo].[Product_Tbl] " +
                                " WHERE [Category] = @카테고리";

                    cmd.CommandText = query;

                    cmd.Parameters.AddWithValue("@카테고리", pCategory);

                    SqlDataReader reader = cmd.ExecuteReader();

                    string[] datas = new string[reader.FieldCount];

                    List<ProductDTO> productList = new List<ProductDTO>();
                    while (reader.Read())
                    {
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            datas[i] = reader.GetValue(i).ToString();
                        }

                        ProductDTO product = new ProductDTO();
                        product.Idx = int.Parse(datas[0]);
                        product.Category = datas[1];
                        product.Name = datas[2];
                        product.Price = int.Parse(datas[3]);
                        product.Stock = int.Parse(datas[4]);
                        product.RegDate = datas[5];


                        productList.Add(product);
                    }
                    this.productList = productList;

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("ProductDAO Search Category" + ex.Message);
            }
        }
        //상품 전체 리스트 받아오기
        public void SearchAll()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DataBase.Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    var query = "SELECT * FROM [dbo].[Product_Tbl]";
                    cmd.CommandText = query;

                    SqlDataReader reader = cmd.ExecuteReader();

                    string[] datas = new string[reader.FieldCount];

                    List<ProductDTO> productList = new List<ProductDTO>();
                    while (reader.Read())
                    {
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            datas[i] = reader.GetValue(i).ToString();
                        }

                        ProductDTO product = new ProductDTO();
                        product.Idx = int.Parse(datas[0]);
                        product.Category = datas[1];
                        product.Name = datas[2];
                        product.Price = int.Parse(datas[3]);
                        product.Stock = int.Parse(datas[4]);
                        product.RegDate = datas[5];


                        productList.Add(product);
                    }
                    this.productList = productList;

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("productDAO SearchAll" + ex.Message);
            }
        }
        //상품 삭제
        public void Delete()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DataBase.Common.ConnString))
                {
                    if (conn.State == ConnectionState.Closed) conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    var query = "";

                    query = "DELETE FROM [dbo].[Product_Tbl] " +
                            " WHERE [Name] = @이름";
                    cmd.CommandText = query;

                    cmd.Parameters.AddWithValue("@이름", pName);

                    var result = cmd.ExecuteNonQuery();
                    if (result == 1)
                    {
                        Console.WriteLine("상품을 삭제하였습니다");
                    }
                    else
                    {
                        Console.WriteLine("상품 삭제를 실패하셨습니다");
                    }
                    Console.ReadKey();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("ProductDAO Delete" + ex.Message);
            }
        }
    }
}
