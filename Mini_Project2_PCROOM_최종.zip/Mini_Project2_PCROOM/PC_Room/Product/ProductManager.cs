﻿using PC_Room.Interface;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PC_Room.Product
{
    class ProductManager : ManagerInterface
    {
        ProductDAO productDAO = new ProductDAO();
        public ProductDTO product { get; set; }
        List<ProductDTO> productList = null;
        public string pName { get; set; }

        public ProductManager() { }

        public void PrintProduct()
        {
            Console.WriteLine();
            Console.WriteLine("메뉴번호 : " + product.Idx);
            Console.WriteLine("카테고리 : " + product.Category);
            Console.WriteLine("    메뉴 : " + product.Name);
            Console.WriteLine("    가격 : " + product.Price);
            Console.WriteLine("  재고량 : " + product.Stock);
            Console.WriteLine("  등록일 : " + product.RegDate);
            Console.WriteLine();
        }

        public void PrintProduct_member()
        {
            Console.WriteLine();
            Console.WriteLine("메뉴번호 : " + product.Idx);
            Console.WriteLine("카테고리 : " + product.Category);
            Console.WriteLine("    메뉴 : " + product.Name);
            Console.WriteLine("    가격 : " + product.Price);
        }

        public void Add()
        {
            while (true)
            {
                Console.Write("카테고리를 입력하세요 : ");
                string category = Console.ReadLine();
                Console.Write("상품명 입력하세요 : ");
                string name = Console.ReadLine();
                Console.Write("가격을 입력하세요 : ");
                string price = Console.ReadLine();
                Console.Write("재고량을 입력하세요 : ");
                string stock = Console.ReadLine();

                if (string.IsNullOrEmpty(category) || string.IsNullOrEmpty(name)
                    || string.IsNullOrEmpty(price) || string.IsNullOrEmpty(stock))
                {
                    Console.WriteLine("빈값은 입력할 수 없습니다.");
                    Console.ReadLine();
                    continue;
                }

                product = new ProductDTO(category, name, int.Parse(price), int.Parse(stock));
                productDAO.product = product;
                productDAO.Insert();

                break;
            }
        }

        public void Update()
        {
            Console.WriteLine("상품수정");
            Console.WriteLine("-------");
            Console.Write("상품명 >> ");
            string name = Console.ReadLine();
            bool isFind = false;

            productDAO.SearchAll();
            productList = productDAO.getProductList();

            foreach (var product in productList)
            {
                if (product.Name.Equals(name))
                {
                    isFind = true;

                    //수정할 상품 정보 출력
                    productDAO.pName = name;
                    productDAO.product = product;
                    productDAO.Search();
                    this.product = productDAO.product;
                    PrintProduct();
                    Console.WriteLine();

                    //수정할 정보 입력
                    Console.Write("수정할 카테고리명을 입력하세요 : ");
                    string pCategory = Console.ReadLine();
                    Console.Write("수정할 상품명을 입력하세요 : ");
                    string pName = Console.ReadLine();
                    Console.Write("수정할 가격을 입력하세요 : ");
                    string pPrice = Console.ReadLine();
                    Console.Write("수정할 재고량을 입력하세요 : ");
                    string pStock = Console.ReadLine();

                    //빈값 예외처리
                    if (string.IsNullOrEmpty(pCategory) || string.IsNullOrEmpty(pName)
                        || string.IsNullOrEmpty(pPrice) || string.IsNullOrEmpty(pStock))
                    {
                        Console.WriteLine("빈값은 입력할 수 없습니다.");
                        Console.ReadLine();
                        continue;
                    }

                    //데이터베이스 수정
                    product.Category = pCategory;
                    product.Name = pName;
                    product.Price = int.Parse(pPrice);
                    product.Stock = int.Parse(pStock);
                    productDAO.product = product;
                    productDAO.Update();

                    Console.WriteLine("-- 수정후 --");

                    //데이터베이스 수정한 값 다시 가져오기
                    this.product = productDAO.product;
                    PrintProduct();
                    break;
                }
            }

            if (!isFind)
            {
                Console.WriteLine("검색한 상품이 없습니다. 다시 확인해 주세요.");
                Console.ReadKey();
            }
        }

        internal void UpdateStock()
        {
            productDAO.product = product;
            productDAO.UpdateStock();
        }

        public void Search()
        {
            Console.Write("찾으실 상품명을 입력하세요 : ");
            string name = Console.ReadLine();
            productDAO.SearchAll();
            productList = productDAO.getProductList();

            foreach (var proc in productList)
            {
                if (proc.Name == name)
                {
                    product = proc;
                    break;
                }
            }

            Console.WriteLine();
            Console.WriteLine("찾으시는 상품명 " + product.Name + " 입니다");
            Console.WriteLine();
            Console.WriteLine("검색하신 상품 가격 " + product.Price + " 입니다");
            Console.ReadLine();
        }

        public void SearchName()
        {
            productDAO.SearchAll();
            productList = productDAO.getProductList();

            foreach (var proc in productList)
            {
                if (pName == proc.Name)
                {
                    product = proc;
                    break;
                }
            }
        }

        public void Searchca()
        {
            string category;
            int select;

            while (true)
            {
                Console.WriteLine("1. 엄마손맛");
                Console.WriteLine("2. 아빠분식");
                Console.WriteLine("3. 이모음료");
                Console.Write("선택 >> ");
                select = int.Parse(Console.ReadLine());

                if (select < 0 || select > 3)
                {
                    Console.WriteLine("[입력오류] 다시입력하세요.");
                    Console.ReadLine();
                    continue;
                }
                else break;
            }

            if (select == 1) category = "엄마손맛";
            else if(select == 2) category = "아빠분식";
            else category = "이모음료";

            productDAO.pCategory = category;
            productDAO.SearchCategory();
            productList = productDAO.getProductList();

            foreach (var proc in productList)
            {
                if (proc.Category == category)
                {
                    product = proc;
                    PrintProduct_member();
                    Console.WriteLine();
                }
            }
            Console.ReadLine();
        }

        public void PrintList()
        {
            productDAO.SearchAll();
            List<ProductDTO> productList = productDAO.getProductList();

            foreach(var p in productList)
            {
                product = p;
                PrintProduct();
            }

            Console.ReadLine();
        }

        public void Delete()
        {
            Console.Write("삭제할 상품명을 입력하세요 : ");
            string name = Console.ReadLine();

            productDAO.pName = name;
            productDAO.Delete();
        }
    }
}
