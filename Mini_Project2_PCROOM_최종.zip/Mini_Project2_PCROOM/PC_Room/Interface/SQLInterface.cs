﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PC_Room.Interface
{
    interface SQLInterface
    {
        void Insert();
        void Update();
        void Search();
        void SearchAll();
        void Delete();
    }
}
