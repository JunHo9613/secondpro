﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PC_Room.Interface
{
    interface ManagerInterface {
        void Add();
        void Update();
        void Delete();
        void PrintList();
        void Search();
    }
}
