﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace CustomerServiceServer
{
    /*
        [관리자]
        A|아이디|A|메세지         >>  전체 보내기
        A|아이디|W|메세지         >>  특정회원에게 답장
        A|L                      >>  접속 중인 회원/비회원 아이디

        [회원]
        M|아이디|메세지           >>  관리자에게 메세지 보내기
    */

    class Server
    {
        static object keyObj = new object();
        // 임계영역 동기화 객체

        static List<Socket> socketList = new List<Socket>();
        // id를 수신하면 socketList에서 idMap과 socketMap으로 이동하여 저장

        static Dictionary<string, Socket> idMap = new Dictionary<string, Socket>();
        static Dictionary<Socket, string> socketMap = new Dictionary<Socket, string>();
        const int PORT = 9000;

        //관리자 아이디
        static string adminId = "Admin";

        //서버 메인
        static void Main(string[] args)
        {
            Socket serverSocket =
                new Socket(AddressFamily.InterNetwork,
                           SocketType.Stream,
                           ProtocolType.Tcp);

            IPEndPoint ipep = new IPEndPoint(IPAddress.Any, PORT);

            serverSocket.Bind(ipep);
            serverSocket.Listen(100); // 이통사와 연결            
            while (true)
            {
                Console.WriteLine("[서버] 접속 대기중...");
                Socket connSocket = serverSocket.Accept();

                // 임계영역 동기화
                Monitor.Enter(keyObj);
                // 리스트에 소켓객체를 등록
                socketList.Add(connSocket);
                Monitor.Exit(keyObj); //하나씩 들어오게 만드는 역할

                Console.WriteLine("[서버] 클라이언트 접속 성공.");
                Thread thread =
                    new Thread(new ParameterizedThreadStart(threadRead));
                thread.Start(connSocket);
                //Console.WriteLine("[서버] 클라이언트 스레드 담당~");
            }
        }

        //Thread 읽기
        static void threadRead(object sock)
        {
            Socket connSocket = (Socket)sock;
            NetworkStream ns = new NetworkStream(connSocket);
            StreamReader sr = new StreamReader(ns);// ReadLine()
            StreamWriter sw = new StreamWriter(ns);// WriteLine()
            // Client가 보내는 데이터를 수신하고 키보드에서 입력받는 것처럼 처리하기 위한 역할


            try  // 정상 실행을 시도
            {
                bool isRun = true; // true일때 작동
                while (isRun)
                {
                    String strMsg = sr.ReadLine();
                    Console.WriteLine("[서버] : 수신 : " + strMsg);

                    isRun = processPacket(strMsg, connSocket, sw, sr);

                    if (strMsg == null)
                        break;
                }
            }
            catch (Exception e)  // 예외처리
            {
                Console.WriteLine(e.Message);
            }
            finally  // 정상이든 예외든 무조건 최종적으로 실행돼서 나오는부분
            {
                removeRegisterSocket(connSocket);

                Console.WriteLine("[서버] 클라이언트 접속 종료...");
                if (sr != null) sr.Close();
                if (ns != null) ns.Close();
                if (connSocket != null) connSocket.Close();
            }
        }

        //소켓 연결 해제
        static void removeRegisterSocket(Socket connSocket)
        {
            Monitor.Enter(keyObj);

            socketList.Remove(connSocket);

            string id = socketMap[connSocket];

            socketMap.Remove(connSocket);
            idMap.Remove(id);

            Monitor.Exit(keyObj);
        }

        //CMD
        //A : Admin(관리자)
        //M : Member(회원)
        //subCmd 
        //A : 전체 메세지(PC방 공지, 알림 등)
        //W : 귓속말(특정 회원에게 답장)
        //L : 회원 아이디 보기


        //전달된 임무 수행
        static bool processPacket(String strPacket, Socket connSocket, StreamWriter sw, StreamReader sr)
        {
            bool isRun = true;
            //메세지



            // if (cmd == "A") { adminId = dataArr[1]; subCmd = dataArr[2]; }

            // Console.WriteLine("[서버] 클라이언트 id 수신 : " + myId);

            // moveListToMap(connSocket, myId);

            bool isEnable = isChatting(connSocket); // 채팅 기능 작동
            isRun = true; // 채팅 기능 작동
            while (isEnable)
            {
                String strCmd = sr.ReadLine();

                String[] dataArr = strCmd.Split(new char[] { '|' });
                string cmd = dataArr[0];    //A:관리자, M:회원
                string subCmd = dataArr[1];   //아이디   
                string mgs = dataArr[2];         //(관리자만 해당)A, W, L
                string receiveId = "";      //관리자가 귓속말하는 회원 아이디
                string msg = "";

                if (cmd == "0")
                    isEnable = false;

                switch (cmd)
                {
                    case "M": //회원
                        if (subCmd == "O")
                        {
                            msg = dataArr[2];
                            Console.WriteLine(mgs);
                            sendAdmin(msg, connSocket); //관리자에게 보내기
                        }
                        else
                        {
                            sw.WriteLine("M|F");
                            sw.Flush();
                        }
                        break;
                    case "A": //관리자
                        if (subCmd == "A")  //전체 보내기
                        {
                            if (isEnable)
                            {
                                msg = dataArr[3];
                                sendAllMsg(msg, connSocket);
                            }
                            else
                            {
                                sw.WriteLine("A|F");
                                sw.Flush();
                            }
                        }
                        else if (subCmd == "W") //특정회원에게 귓속말
                        {
                            if (isEnable)
                            {
                                receiveId = dataArr[3]; // 저장된 ID값 받아오기
                                msg = dataArr[4]; //
                                sendWhisper(msg, connSocket, receiveId);
                            }
                            else
                            {
                                sw.WriteLine("A|F");
                                sw.Flush();
                            }
                        }
                        else if (subCmd == "L") //접속된 아이디 리스트 보내기
                        {
                            sendWhisperIdList(sw, connSocket);
                        }
                        break;
                    case "E": //Exit
                        Console.WriteLine("[서버] 클라이언트 종료 요청");
                        isRun = false;
                        break;
                }
            }
            return isRun;
        }

        static void moveListToMap(Socket connSocket, string id) // ??
        {
            Monitor.Enter(keyObj);
            socketList.Remove(connSocket); // 소켓 리스트 제거

            idMap.Add(id, connSocket); // idMap 추가
            socketMap.Add(connSocket, id); // socketMap 추가

            Monitor.Exit(keyObj);
        }

        static bool isChatting(Socket connSocket) // 
        {
            bool isEnable = true;
            Monitor.Enter(keyObj);
            foreach (Socket socket in socketList)
            {
                if (socket == connSocket)
                {
                    isEnable = false;
                    break;
                }
            }
            Monitor.Exit(keyObj);

            return isEnable;
        }

        //서버에 접속해 있는 회원 아이디 보내기
        static void sendWhisperIdList(StreamWriter sw, Socket exceptionSocket)
        {
            Monitor.Enter(keyObj);

            string packet = "A|L";
            foreach (var data in idMap) // foreach문 사용해서 순회
            {
                string id = data.Key;
                Socket socket = data.Value;
                if (socket != exceptionSocket)
                {
                    packet += id + "|";
                }
            }

            sw.WriteLine(packet);
            sw.Flush();  // stream에 남아 있는 데이터를 강제로 내보냄

            Monitor.Exit(keyObj);
        }

        //관리자에게 보내기
        static void sendAdmin(string strMsg, Socket sendSocket)
        {
            Monitor.Enter(keyObj);

            //보내는 아이디
            string sendId = socketMap[sendSocket];

            Socket receiveSocket = idMap[adminId];

            NetworkStream ns = new NetworkStream(receiveSocket);
            StreamWriter sw = new StreamWriter(ns);

            // W:귓속말|관리자아이디|메세지
            sw.WriteLine(String.Format("M|{0}|{1}", sendId, strMsg));
            sw.Flush();

            Monitor.Exit(keyObj);
        }

        //특정회원에게 답장
        static void sendWhisper(string strMsg, Socket sendSocket, string receiveId)
        {
            Monitor.Enter(keyObj);

            string sendId = socketMap[sendSocket];

            Socket receiveSocket = idMap[receiveId];

            NetworkStream ns = new NetworkStream(receiveSocket);
            StreamWriter sw = new StreamWriter(ns);

            // W:귓속말|관리자아이디|메세지
            sw.WriteLine(String.Format("A|{0}|{1}", sendId, strMsg));
            sw.Flush();

            Monitor.Exit(keyObj);
        }

        //전체 보내기
        static void sendAllMsg(String strMsg, Socket exceptionSocket)
        {
            Monitor.Enter(keyObj);

            string sendId = socketMap[exceptionSocket];

            //접속되어 있는 회원 모두에게 보낸다
            foreach (var data in idMap)
            {
                string id = data.Key;// key - id
                Socket socket = data.Value; // value = socket
                if (id != sendId)
                {
                    NetworkStream ns = new NetworkStream(socket);
                    StreamWriter sw = new StreamWriter(ns);

                    // A:전체보내기|관리자아이디|메세지
                    sw.WriteLine(String.Format("A|{0}|{1}", sendId, strMsg));
                    sw.Flush();
                }
            }

            Monitor.Exit(keyObj);
        }
    }
}